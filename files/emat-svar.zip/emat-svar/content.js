(function () {
  const DEFAULTS = { enabled: true, hint: true, position: 'card', chipBg: '#ffe45c', chipInk: '#1b2a6b', check: true, moving: false, positions: {}, sizes: {}, autoDysten: false, nextDelay: 1 };

  const SIZE_DEFAULTS = { dysten: 'l', emat1: 's', other: 'm' };
  const SITE = (() => {
    if (/\/dysten(\/|$)/i.test(location.pathname)) return 'dysten';
    if (/(^|\.)emat1\.dk$/i.test(location.hostname)) return 'emat1';
    return 'other';
  })();

  // Auto-næste findes kun på Emat dysten.
  const autoOn = () => SITE === 'dysten' && !!settings.autoDysten;

  const currentSize = () => (settings.sizes && settings.sizes[SITE]) || SIZE_DEFAULTS[SITE];
  const CHIP_ID = 'emat-svar';
  const STYLE_ID = 'emat-svar-style';
  const LAYER_ID = 'emat-svar-felter';
  const KNOB_ID = 'emat-dreje';

  let settings = { ...DEFAULTS };
  let lastQuestion = null;
  let dragging = false;      // trækkes ikonet lige nu?
  let dragEndedAt = 0;
  let hideTimer = 0;         // rigtig/forkert går selv tilbage til hint-ikonet
  let revealed = false;      // er svaret vist (efter klik på hint-ikonet)?
  let revealedFor = null;    // opgaven som 'revealed' gælder for

  const EPS = 1e-9;

  const pTrim = (p) => { while (p.length > 1 && Math.abs(p[p.length - 1]) < EPS) p.pop(); return p; };
  const pAdd = (a, b, sign) => {
    const r = [];
    for (let i = 0; i < Math.max(a.length, b.length); i++) r.push((a[i] || 0) + sign * (b[i] || 0));
    return pTrim(r);
  };
  const pMul = (a, b) => {
    const r = new Array(a.length + b.length - 1).fill(0);
    for (let i = 0; i < a.length; i++) for (let j = 0; j < b.length; j++) r[i + j] += a[i] * b[j];
    if (r.length > 5) throw new Error('grad');
    return pTrim(r);
  };
  const pDiv = (a, b) => {
    if (b.length > 1) throw new Error('ikke-lineær');
    if (Math.abs(b[0]) < EPS) throw new Error('division med nul');
    return a.map((c) => c / b[0]);
  };
  const pPow = (a, n) => {
    if (!Number.isInteger(n) || n < 0 || n > 6) throw new Error('potens');
    let r = [1];
    for (let k = 0; k < n; k++) r = pMul(r, a);
    return r;
  };

  function parsePoly(s) {
    let i = 0;
    let variable = null;
    const peek = () => s[i];

    function number() {
      const m = /^(\d+(\.\d+)?|\.\d+)/.exec(s.slice(i));
      if (!m) throw new Error('tal');
      i += m[0].length;
      return [parseFloat(m[0])];
    }
    function atom() {
      const c = peek();
      if (c === '(') {
        i++;
        const v = expr();
        if (peek() !== ')') throw new Error('parentes');
        i++;
        return v;
      }
      if (c && /[a-z]/.test(c)) {
        if (variable && variable !== c) throw new Error('flere ubekendte');
        variable = c;
        i++;
        return [0, 1];
      }
      return number();
    }
    function power() {
      let v = atom();
      while (peek() === '^') {
        i++;
        const m = /^-?\d+/.exec(s.slice(i));
        if (!m) throw new Error('eksponent');
        i += m[0].length;
        const n = parseInt(m[0], 10);
        if (n < 0) {
          if (v.length > 1) throw new Error('ikke-lineær');
          v = [Math.pow(v[0], n)];
        } else {
          v = pPow(v, n);
        }
      }
      return v;
    }
    function unary() {
      if (peek() === '-') { i++; return pMul(unary(), [-1]); }
      if (peek() === '+') { i++; return unary(); }
      return power();
    }
    function term() {
      let v = unary();
      for (;;) {
        const c = peek();
        if (c === '*') { i++; v = pMul(v, unary()); }
        else if (c === '/') { i++; v = pDiv(v, unary()); }
        else if (c && (/[a-z(]/.test(c) || (/\d/.test(c) && s[i - 1] === ')'))) v = pMul(v, power());
        else break;
      }
      return v;
    }
    function expr() {
      let v = term();
      while (peek() === '+' || peek() === '-') {
        const op = s[i++];
        v = pAdd(v, term(), op === '+' ? 1 : -1);
      }
      return v;
    }

    const poly = expr();
    if (i !== s.length) throw new Error('rest');
    return { poly, variable };
  }

  const fmt = (v) => {
    let r = Math.round(v * 1e6) / 1e6;
    if (Object.is(r, -0)) r = 0;
    return String(r).replace('.', ',');
  };
  const isExact = (v) => Math.abs(v - Math.round(v * 1e6) / 1e6) < 1e-9;
  const fmtApprox = (v) => (isExact(v) ? '' : '≈ ') + fmt(v);

  function cleanMath(raw) {
    let t = raw
      .replace(/^[^\n=]*?[a-zæøåA-ZÆØÅ]{2,}[^\n:=]{0,15}[^\s:=]:\s+/, '')
      .replace(/[−–—]/g, '-')
      .replace(/[×·•∙⋅∗●]/g, '*')
      .replace(/÷/g, '/')
      .replace(/²/g, '^2')
      .replace(/³/g, '^3')
      .replace(/[a-zæøåA-ZÆØÅ]{2,}/g, ' ')
      .replace(/(\d)\s*x\s*(?=\d)/gi, '$1*')
      .replace(/^[\s:;,.]+/, '')
      .replace(/:/g, '/')
      .replace(/,/g, '.');

    if (t.includes('=')) {
      if (!/[a-z]/i.test(t)) t = t.replace(/[?□▢_]+/g, 'x');
    } else {
      t = t.replace(/[?]+/g, '');
    }
    return t.toLowerCase().replace(/\s+/g, '');
  }

  function solveText(raw) {
    const s = cleanMath(raw);
    if (!/^[0-9a-z+\-*\/().^=]+$/.test(s)) throw new Error('tegn');
    const parts = s.split('=');
    if (parts.length > 2) throw new Error('flere =');

    if (parts.length === 1 || !parts[0] || !parts[1]) {
      const expr = parts[0] || parts[1];
      if (!expr) throw new Error('tomt');
      const { poly } = parsePoly(expr);
      if (poly.length > 1) throw new Error('ubekendt uden ligning');
      if (!Number.isFinite(poly[0])) throw new Error('uendelig');
      return { kind: 'value', text: fmt(poly[0]) };
    }

    const L = parsePoly(parts[0]);
    const R = parsePoly(parts[1]);
    if (L.variable && R.variable && L.variable !== R.variable) throw new Error('flere ubekendte');
    const v = L.variable || R.variable || 'x';
    const p = pAdd(L.poly, R.poly, -1);
    const deg = p.length - 1;
    const name = v + ' = ';

    if (deg === 0) {
      return { kind: 'eq', text: Math.abs(p[0]) < 1e-9 ? 'Alle tal passer' : 'Ingen løsning' };
    }
    if (deg === 1) {
      return { kind: 'eq', text: name + fmtApprox(-p[0] / p[1]) };
    }
    if (deg === 2) {
      const [c, b, a] = p;
      const d = b * b - 4 * a * c;
      if (d < -1e-9) return { kind: 'eq', text: 'Ingen løsning' };
      if (Math.abs(d) <= 1e-9) return { kind: 'eq', text: name + fmtApprox(-b / (2 * a)) };
      const r1 = (-b - Math.sqrt(d)) / (2 * a);
      const r2 = (-b + Math.sqrt(d)) / (2 * a);
      const [lo, hi] = r1 < r2 ? [r1, r2] : [r2, r1];
      return { kind: 'eq', text: name + fmtApprox(lo) + '  eller  ' + name + fmtApprox(hi) };
    }
    throw new Error('for høj grad');
  }

  const mKey = (m) => Object.keys(m).sort().filter((v) => m[v]).map((v) => v + ':' + m[v]).join(',');
  const mParse = (k) => {
    const m = {};
    if (k) k.split(',').forEach((p) => { const [v, e] = p.split(':'); m[v] = +e; });
    return m;
  };
  const mDeg = (k) => (k ? k.split(',').reduce((s, p) => s + +p.split(':')[1], 0) : 0);

  const qClean = (p) => { for (const [k, c] of Array.from(p)) if (Math.abs(c) < EPS) p.delete(k); return p; };
  const qConst = (c) => qClean(new Map([['', c]]));
  const qAdd = (a, b, sign) => {
    const r = new Map(a);
    for (const [k, c] of b) r.set(k, (r.get(k) || 0) + sign * c);
    return qClean(r);
  };
  const qMul = (a, b) => {
    const r = new Map();
    for (const [ka, ca] of a) {
      for (const [kb, cb] of b) {
        const m = mParse(ka);
        for (const [v, e] of Object.entries(mParse(kb))) m[v] = (m[v] || 0) + e;
        const k = mKey(m);
        if (mDeg(k) > 12) throw new Error('grad');
        r.set(k, (r.get(k) || 0) + ca * cb);
      }
    }
    return qClean(r);
  };
  const qPow = (a, n) => {
    if (!Number.isInteger(n) || n < 0 || n > 6) throw new Error('potens');
    let r = qConst(1);
    for (let i = 0; i < n; i++) r = qMul(r, a);
    return r;
  };
  const qDiv = (a, b) => {
    if (b.size !== 1 || !b.has('')) throw new Error('division');
    const d = b.get('');
    return new Map(Array.from(a, ([k, c]) => [k, c / d]));
  };

  function parseMulti(s) {
    let i = 0;
    const peek = () => s[i];

    function number() {
      const m = /^(\d+(\.\d+)?|\.\d+)/.exec(s.slice(i));
      if (!m) throw new Error('tal');
      i += m[0].length;
      return qConst(parseFloat(m[0]));
    }
    function atom() {
      const c = peek();
      if (c === '(') {
        i++;
        const v = expr();
        if (peek() !== ')') throw new Error('parentes');
        i++;
        return v;
      }
      if (c && /[a-z]/.test(c)) { i++; return new Map([[c + ':1', 1]]); }
      return number();
    }
    function power() {
      let v = atom();
      while (peek() === '^') {
        i++;
        const m = /^\d+/.exec(s.slice(i));
        if (!m) throw new Error('eksponent');
        i += m[0].length;
        v = qPow(v, parseInt(m[0], 10));
      }
      return v;
    }
    function unary() {
      if (peek() === '-') { i++; return qMul(unary(), qConst(-1)); }
      if (peek() === '+') { i++; return unary(); }
      return power();
    }
    function term() {
      let v = unary();
      for (;;) {
        const c = peek();
        if (c === '*') { i++; v = qMul(v, unary()); }
        else if (c === '/') { i++; v = qDiv(v, unary()); }
        else if (c && (/[a-z(]/.test(c) || (/\d/.test(c) && s[i - 1] === ')'))) v = qMul(v, power());
        else break;
      }
      return v;
    }
    function expr() {
      let v = term();
      while (peek() === '+' || peek() === '-') {
        const op = s[i++];
        v = qAdd(v, term(), op === '+' ? 1 : -1);
      }
      return v;
    }

    const p = expr();
    if (i !== s.length) throw new Error('rest');
    return p;
  }

  const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';
  const sup = (n) => String(n).split('').map((d) => SUP[+d]).join('');

  function fmtPoly(p) {
    if (!p.size) return '0';
    const terms = Array.from(p, ([k, c]) => ({ k, c, deg: mDeg(k), m: mParse(k) }));
    terms.sort((x, y) => {
      if (!x.k !== !y.k) return x.k ? -1 : 1;
      if (x.deg !== y.deg) return y.deg - x.deg;
      const vars = Array.from(new Set([...Object.keys(x.m), ...Object.keys(y.m)])).sort();
      for (const v of vars) {
        const d = (y.m[v] || 0) - (x.m[v] || 0);
        if (d) return d;
      }
      return 0;
    });
    let out = '';
    terms.forEach((t, i) => {
      const abs = Math.abs(t.c);
      const body = Object.keys(t.m).sort().map((v) => v + (t.m[v] > 1 ? sup(t.m[v]) : '')).join('');
      const txt = (body && Math.abs(abs - 1) < EPS ? '' : fmt(abs)) + body;
      out += i === 0 ? (t.c < 0 ? '-' : '') + txt : (t.c < 0 ? ' - ' : ' + ') + txt;
    });
    return out;
  }

  const REDUCE_KEY = /reducer|forenkl/i;
  const REDUCE_WORDS = /reducer(?:\s+udtrykket)?|forenkl(?:\s+udtrykket)?|udtrykket/gi;

  function reduceText(raw) {
    let t = raw
      .replace(REDUCE_WORDS, ' ')
      .replace(/[−–—]/g, '-')
      .replace(/[×·•∙⋅∗●]/g, '*')
      .replace(/÷/g, '/')
      .replace(/²/g, '^2')
      .replace(/³/g, '^3')
      .replace(/(\d)\s*x\s*(?=\d)/gi, '$1*')
      .replace(/^[\s:;,.]+/, '')
      .replace(/:/g, '/')
      .replace(/,/g, '.')
      .toLowerCase()
      .replace(/\s+/g, '')
      .replace(/=+$/, '');
    if (!t || !/^[0-9a-z+\-*\/().^]+$/.test(t)) throw new Error('tegn');
    if (/[a-z]{4,}/.test(t)) throw new Error('ord');
    return fmtPoly(parseMulti(t));
  }

  const NUM = '(\\d+(?:[.,]\\d+)?)';

  function parseFractionOf(raw) {
    const m = /(\d+)\s*[\/\s]\s*(\d+)\s*af\s*(\d+(?:[.,]\d+)?)/i.exec(raw);
    if (!m) return null;
    return { num: +m[1], den: +m[2], of: parseFloat(m[3].replace(',', '.')) };
  }

  function parsePercentOf(raw) {
    const m = new RegExp(NUM + '\\s*(?:%|procent)\\s*af\\s*' + NUM, 'i').exec(raw);
    if (!m) return null;
    return { pct: parseFloat(m[1].replace(',', '.')), of: parseFloat(m[2].replace(',', '.')) };
  }

  function parseFarv(raw) {
    const m = /farv\s+(\d+)\s*[\/\s]\s*(\d+)\s*af\s+(?!\d)[a-zæøå]+/i.exec(raw);
    if (!m) return null;
    return { num: +m[1], den: +m[2] };
  }

  function prettyQuestion(raw) {
    return raw
      .replace(/\s+/g, ' ')
      .replace(/(\d+)\s*[\/\s]\s*(\d+)(?=\s*af\b)/i, '$1/$2')
      .trim();
  }

  function parseColor(str) {
    if (!str || str === 'transparent') return { a: 0, ink: false };
    const m = str.match(/-?\d*\.?\d+/g);
    if (!m || m.length < 3) return { a: 1, ink: true };
    const [r, g, b] = m.map(Number);
    const a = m.length > 3 ? Number(m[3]) : 1;
    return { a, ink: a > 0.02 && !(r >= 250 && g >= 250 && b >= 250) };
  }

  function selfPaints(el) {
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || cs.visibility === 'collapse') return false;
    if (parseFloat(cs.opacity) < 0.05) return false;

    if (typeof SVGElement !== 'undefined' && el instanceof SVGElement) {
      const fillOn = cs.fill && cs.fill !== 'none' && parseFloat(cs.fillOpacity) > 0.02 && parseColor(cs.fill).ink;
      const strokeOn = cs.stroke && cs.stroke !== 'none' && parseFloat(cs.strokeWidth) > 0 && parseColor(cs.stroke).ink;
      return !!(fillOn || strokeOn);
    }
    if (/^(IMG|CANVAS|VIDEO|INPUT|BUTTON|SELECT)$/.test(el.tagName)) return true;
    if (parseColor(cs.backgroundColor).ink) return true;
    if (cs.backgroundImage && cs.backgroundImage !== 'none') return true;
    for (const side of ['Top', 'Right', 'Bottom', 'Left']) {
      const w = parseFloat(cs['border' + side + 'Width']);
      const st = cs['border' + side + 'Style'];
      if (w > 0 && st !== 'none' && st !== 'hidden' && parseColor(cs['border' + side + 'Color']).ink) return true;
    }
    if (cs.boxShadow && cs.boxShadow !== 'none') return true;
    return false;
  }

  function chainShown(el, root) {
    for (let p = el; p && p !== root.parentElement; p = p.parentElement) {
      const cs = getComputedStyle(p);
      if (cs.display === 'none') return false;
      if (parseFloat(cs.opacity) < 0.05) return false;
    }
    return getComputedStyle(el).visibility !== 'hidden' || !!el.querySelector('*');
  }

  function cellShown(el, root) {
    if (!chainShown(el, root)) return false;
    if (selfPaints(el)) return true;
    const kids = el.querySelectorAll('*');
    for (const k of kids) if (selfPaints(k) && chainShown(k, root)) return true;
    return false;
  }

  function findCells() {
    const root = document.getElementById('Div_Farv');
    if (!root) return [];

    const cand = [];
    root.querySelectorAll('*').forEach((el) => {
      const r = el.getBoundingClientRect();
      if (r.width < 14 || r.width > 120) return;
      if (Math.abs(r.width - r.height) > 4) return;
      cand.push({ el, r });
    });

    const set = new Set(cand.map((c) => c.el));
    let outer = cand.filter((c) => {
      let p = c.el.parentElement;
      while (p && p !== root) {
        if (set.has(p)) return false;
        p = p.parentElement;
      }
      return true;
    });

    if (outer.length) {
      const buckets = new Map();
      outer.forEach((c) => {
        const k = Math.round(c.r.width / 3);
        buckets.set(k, (buckets.get(k) || 0) + 1);
      });
      let bestK = null, bestN = 0;
      buckets.forEach((n, k) => { if (n > bestN) { bestN = n; bestK = k; } });
      outer = outer.filter((c) => Math.abs(Math.round(c.r.width / 3) - bestK) <= 1);
    }

    const shown = outer.filter((c) => cellShown(c.el, root));
    outer = shown.length ? shown : outer;

    outer.sort((a, b) => a.r.top - b.r.top || a.r.left - b.r.left);
    const rows = [];
    outer.forEach((c) => {
      const row = rows[rows.length - 1];
      if (row && Math.abs(c.r.top - row[0].r.top) <= c.r.height / 2) row.push(c);
      else rows.push([c]);
    });
    rows.forEach((row) => row.sort((a, b) => a.r.left - b.r.left));
    return rows.flat().map((c) => c.el);
  }

  function clearOverlay() {
    const layer = document.getElementById(LAYER_ID);
    if (layer) layer.remove();
  }

  function drawOverlay(cells) {
    let layer = document.getElementById(LAYER_ID);
    if (!layer) {
      layer = document.createElement('div');
      layer.id = LAYER_ID;
      layer.style.cssText =
        'position:absolute;top:0;left:0;width:0;height:0;pointer-events:none;z-index:2147483646;';
      document.documentElement.appendChild(layer);
    }
    while (layer.children.length > cells.length) layer.lastChild.remove();
    while (layer.children.length < cells.length) {
      const d = document.createElement('div');
      d.style.cssText =
        'position:absolute;box-sizing:border-box;pointer-events:none;' +
        'background:rgba(70,70,70,.16);border-radius:2px;';
      layer.appendChild(d);
    }
    const sx = window.scrollX, sy = window.scrollY;
    cells.forEach((el, i) => {
      const r = el.getBoundingClientRect();
      const d = layer.children[i];
      d.style.left = (r.left + sx) + 'px';
      d.style.top = (r.top + sy) + 'px';
      d.style.width = r.width + 'px';
      d.style.height = r.height + 'px';
    });
  }

  function updateFarv(chip, f, show) {
    const a = chip.querySelector('.emat-a');
    const setText = (t) => { if (a.textContent !== t) a.textContent = t; };
    const cells = findCells();

    if (!cells.length) {
      chip.dataset.state = 'error';
      setText('Kunne ikke finde felterne');
      clearOverlay();
      return;
    }
    const n = f.den ? (cells.length * f.num) / f.den : NaN;
    if (!Number.isFinite(n) || Math.abs(n - Math.round(n)) > 1e-6) {
      chip.dataset.state = 'error';
      setText(cells.length + ' felter kan ikke deles i ' + f.den + ' lige dele');
      clearOverlay();
      return;
    }
    const count = Math.round(n);
    chip.dataset.state = 'ok';
    setText(count + (count === 1 ? ' felt' : ' felter'));
    if (show) drawOverlay(cells.slice(0, count));
    else clearOverlay();
  }

  const CSS = `
    #${CHIP_ID} {
      all: initial;
      box-sizing: border-box;
      display: inline-flex;
      align-items: center;
      gap: 10px;
      vertical-align: middle;
      white-space: nowrap;
      padding: 6px 14px;
      border-radius: 10px;
      background: var(--emat-bg, #ffe45c);
      color: var(--emat-ink, #1b2a6b);
      font: 700 20px/1.15 "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif;
      font-variant-numeric: tabular-nums;
      box-shadow: 0 0 0 1.5px rgba(27,42,107,.16);
      animation: emat-svar-pop .2s ease-out;
      cursor: default;
      pointer-events: auto;
      user-select: none;
    }
    #${CHIP_ID} span {
      all: initial;
      cursor: inherit;
      font: inherit;
      color: inherit;
      white-space: pre;
      font-variant-numeric: tabular-nums;
    }
    #${CHIP_ID} .emat-q { display: none; font-size: .62em; font-weight: 600; opacity: .72; }
    #${CHIP_ID} .emat-a { display: inline; }

    #${CHIP_ID}[data-size="s"] { font-size: 15px; padding: 5px 11px; }
    #${CHIP_ID}[data-size="m"] { font-size: 20px; }
    #${CHIP_ID}[data-size="l"] { font-size: 30px; padding: 8px 18px; }

    #${CHIP_ID}[data-mode="inline"],
    #${CHIP_ID}[data-mode="card"],
    #${CHIP_ID}[data-mode="custom"] {
      position: absolute;
      z-index: 2147483647;
      margin: 0;
      left: 0;
      top: 0;
    }

    #${CHIP_ID}[data-mode="tl"], #${CHIP_ID}[data-mode="tr"],
    #${CHIP_ID}[data-mode="bl"], #${CHIP_ID}[data-mode="br"] {
      position: fixed;
      z-index: 2147483647;
      margin: 0;
      flex-direction: column;
      align-items: flex-start;
      gap: 3px;
      padding: 10px 16px;
    }
    #${CHIP_ID}[data-mode="tl"] { top: 16px; left: 16px; }
    #${CHIP_ID}[data-mode="tr"] { top: 16px; right: 16px; }
    #${CHIP_ID}[data-mode="bl"] { bottom: 16px; left: 16px; }
    #${CHIP_ID}[data-mode="br"] { bottom: 16px; right: 16px; }
    #${CHIP_ID}[data-mode="tl"] .emat-q, #${CHIP_ID}[data-mode="tr"] .emat-q,
    #${CHIP_ID}[data-mode="bl"] .emat-q, #${CHIP_ID}[data-mode="br"] .emat-q { display: block; }

    #${CHIP_ID}[data-state="error"] {
      background: #e9ecf6;
      color: #3c4466;
      font-weight: 600;
      font-size: 14px;
      box-shadow: 0 0 0 1.5px rgba(60,68,102,.2);
    }

    /* Emat dysten: hint-ikonet vises ikke (auto-udfyldning virker stadig) */
    #${CHIP_ID}[data-site="dysten"][data-reveal="0"] { display: none !important; }

    /* Rigtig / forkert */
    #${CHIP_ID}[data-reveal="1"][data-verdict="ok"] {
      background: #198754; color: #fff;
      box-shadow: 0 0 0 1.5px rgba(25,135,84,.3);
    }
    #${CHIP_ID}[data-reveal="1"][data-verdict="bad"] {
      background: #c62828; color: #fff;
      box-shadow: 0 0 0 1.5px rgba(198,40,40,.3);
    }

    /* Flyt ikonet */
    #${CHIP_ID}[data-moving="1"] { cursor: move; outline: 2px dashed #e8590c; outline-offset: 4px; touch-action: none; }

    /* Drejehåndtag på vinkelmåleren */
    #${KNOB_ID} { position: absolute; z-index: 102; cursor: grab; touch-action: none; }
    #${KNOB_ID}.drag { cursor: grabbing; }

    /* Hint-ikon (svaret er skjult) */
    #${CHIP_ID}[data-hint="1"] { cursor: default; }
    #${CHIP_ID} .emat-hint { display: none; width: 1.25em; height: 1.25em; }
    #${CHIP_ID} .emat-hint svg { display: block; width: 100%; height: 100%; }
    #${CHIP_ID}[data-reveal="0"] {
      padding: .42em !important;
      border-radius: 50% !important;
      align-items: center !important;
      gap: 0 !important;
    }
    #${CHIP_ID}[data-reveal="0"] .emat-hint { display: block; }
    #${CHIP_ID}[data-reveal="0"] .emat-q,
    #${CHIP_ID}[data-reveal="0"] .emat-a { display: none !important; }

    @keyframes emat-svar-pop {
      from { transform: scale(.94); opacity: .35; }
      to   { transform: none; opacity: 1; }
    }
    @media (prefers-reduced-motion: reduce) {
      #${CHIP_ID} { animation: none !important; }
    }
  `;

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const st = document.createElement('style');
    st.id = STYLE_ID;
    st.textContent = CSS;
    (document.head || document.documentElement).appendChild(st);
  }

  const isVisible = (el) => !!el && el.getClientRects().length > 0;

  function reallyVisible(el) {
    if (!isVisible(el)) return false;
    for (let p = el; p && p !== document.documentElement; p = p.parentElement) {
      const cs = getComputedStyle(p);
      if (cs.display === 'none' || parseFloat(cs.opacity) < 0.05) return false;
      if (p === el && cs.visibility !== 'visible') return false;
    }
    const r = el.getBoundingClientRect();
    return r.width >= 14 && r.height >= 12;
  }

  const MATH_ONLY = /^[\s\d+\-−–—×÷*·∙⋅:\/=?().,x^²³%□]+$/i;
  const DATE_LIKE = /^\d{1,4}\s*[-.\/]\s*\d{1,2}\s*[-.\/]\s*\d{1,4}$/;
  let fallbackQ = null;

  function looksLikeQuestion(t) {
    return t.length >= 3 && t.length <= 60 &&
      /\d/.test(t) && /[+\-−–—×÷*·∙⋅:\/=x]/i.test(t) &&
      MATH_ONLY.test(t) && !DATE_LIKE.test(t);
  }

  function findQuestionFallback() {
    if (fallbackQ && fallbackQ.isConnected && reallyVisible(fallbackQ) &&
        looksLikeQuestion(fallbackQ.innerText.trim())) return fallbackQ;
    fallbackQ = null;
    if (!document.body) return null;

    let best = null, bestSize = 0, bestDepth = -1;
    const els = document.body.querySelectorAll('div,span,p,td,th,label,h1,h2,h3,h4,b,strong,font,center');
    for (const el of els) {
      if (el.closest('#' + CHIP_ID)) continue;
      const tc = el.textContent;
      if (tc.length > 80 || !/\d/.test(tc)) continue;
      if (el.querySelector('input,textarea,select,button')) continue;
      if (!reallyVisible(el)) continue;
      const t = el.innerText.trim();
      if (!looksLikeQuestion(t)) continue;
      const size = parseFloat(getComputedStyle(el).fontSize) || 0;
      if (size < 16) continue;
      let depth = 0;
      for (let p = el; p; p = p.parentElement) depth++;
      if (size > bestSize || (size === bestSize && depth > bestDepth)) {
        best = el; bestSize = size; bestDepth = depth;
      }
    }
    fallbackQ = best;
    return best;
  }

  const qNode = () => document.getElementById('Label_Spg') || findQuestionFallback();

  const FIELD_SEL =
    'input:not([type=hidden]):not([type=radio]):not([type=checkbox]):not([type=button]):not([type=submit]),' +
    'textarea, select, [contenteditable=""], [contenteditable="true"]';

  function visibleFields() {
    return Array.from(document.querySelectorAll(FIELD_SEL)).filter(
      (el) => !el.closest('#' + CHIP_ID) && reallyVisible(el)
    );
  }

  function answerBox() {
    const named = document.getElementById('Textbox_BrugersvarA');
    if (named && reallyVisible(named)) return named;
    const qEl = qNode();
    const raw = qEl ? qEl.innerText.trim() : '';
    const qr = (questionEl() && questionEl().getBoundingClientRect()) || (raw && visibleTextRect(raw));
    if (!qr) return null;
    const dist = (f) => {
      const r = f.getBoundingClientRect();
      return Math.max(0, r.top - qr.bottom, qr.top - r.bottom);
    };
    const near = visibleFields().filter((f) => dist(f) <= 140);
    near.sort((a, b) => dist(a) - dist(b));
    return near[0] || null;
  }

  function questionEl() {
    const q = qNode();
    if (!q || !isVisible(q)) return null;
    const r = q.getBoundingClientRect();
    return r.width > 0 && r.height > 0 ? q : null;
  }

  const unionOf = (rects) => ({
    left: Math.min(...rects.map((x) => x.left)),
    right: Math.max(...rects.map((x) => x.right)),
    top: Math.min(...rects.map((x) => x.top)),
    bottom: Math.max(...rects.map((x) => x.bottom))
  });

  let textCache = { key: null, node: null };
  function visibleTextRect(raw) {
    const words = raw.match(/[a-zæøåA-ZÆØÅ]{2,}/g);
    const target = (words ? words[words.length - 1] : '=').toLowerCase();
    const key = raw + '|' + target;

    const rectOf = (n) => {
      if (!n || !n.isConnected) return null;
      const el = n.parentElement;
      if (!el || getComputedStyle(el).visibility === 'hidden') return null;
      const range = document.createRange();
      range.selectNodeContents(n);
      const rects = Array.from(range.getClientRects()).filter((x) => x.width > 0 && x.height > 0);
      return rects.length ? unionOf(rects) : null;
    };

    if (textCache.key === key) {
      const r = rectOf(textCache.node);
      if (r) return r;
    }
    const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const n = walker.currentNode;
      const el = n.parentElement;
      if (!el || el.closest('#' + CHIP_ID + ',#' + LAYER_ID + ',script,style,noscript,textarea')) continue;
      if (!n.nodeValue.toLowerCase().includes(target)) continue;
      const r = rectOf(n);
      if (r) { textCache = { key, node: n }; return r; }
    }
    return null;
  }

  function inlineAnchor() {
    const tb = answerBox();
    if (tb) {
      const r = tb.getBoundingClientRect();
      let right = r.right;
      const lab = document.getElementById('Label_BnA');
      if (lab && isVisible(lab) && lab.textContent.trim()) {
        const lr = lab.getBoundingClientRect();
        const sameLine = Math.abs((lr.top + lr.bottom) / 2 - (r.top + r.bottom) / 2) < Math.max(r.height, lr.height);
        if (sameLine && lr.left >= r.left) right = Math.max(right, lr.right);
      }
      return { left: r.left, right, top: r.top, bottom: r.bottom };
    }

    const q = questionEl();
    if (!q) {
      const qEl = qNode();
      const raw = qEl ? qEl.innerText.trim() : '';
      const t = raw ? visibleTextRect(raw) : null;
      if (t) return t;
      const grid = document.getElementById('Div_Farv');
      if (grid && isVisible(grid)) {
        const g = grid.getBoundingClientRect();
        return { left: g.left, right: g.right, top: g.top, bottom: g.top + 30 };
      }
      return null;
    }
    const range = document.createRange();
    range.selectNodeContents(q);
    const rects = Array.from(range.getClientRects()).filter((x) => x.width > 0 && x.height > 0);
    if (!rects.length) {
      const r = q.getBoundingClientRect();
      return { left: r.left, right: r.right, top: r.top, bottom: r.bottom };
    }
    let u = {
      left: Math.min(...rects.map((x) => x.left)),
      right: Math.max(...rects.map((x) => x.right)),
      top: Math.min(...rects.map((x) => x.top)),
      bottom: Math.max(...rects.map((x) => x.bottom))
    };
    if (u.bottom - u.top > 90) {
      const lastBottom = Math.max(...rects.map((x) => x.bottom));
      const lastLine = rects.filter((x) => x.bottom > lastBottom - 6);
      u = {
        left: Math.min(...lastLine.map((x) => x.left)),
        right: Math.max(...lastLine.map((x) => x.right)),
        top: Math.min(...lastLine.map((x) => x.top)),
        bottom: lastBottom
      };
    }
    return u;
  }

  function positionInline(chip) {
    const a = inlineAnchor();
    if (!a) return;
    const gap = 12;
    const cw = chip.offsetWidth, ch = chip.offsetHeight;
    let left = a.right + gap;
    let top = (a.top + a.bottom) / 2 - ch / 2;
    if (left + cw > document.documentElement.clientWidth - 6) {
      left = Math.max(6, a.left);
      top = a.bottom + 8;
    }
    const fields = visibleFields().map((f) => f.getBoundingClientRect());
    const hits = () => fields.filter((f) =>
      left < f.right + 2 && left + cw > f.left - 2 && top < f.bottom + 2 && top + ch > f.top - 2);
    for (let n = 0; n < 6; n++) {
      const h = hits();
      if (!h.length) break;
      left = Math.max(...h.map((f) => f.right)) + gap;
    }
    if (hits().length || left + cw > document.documentElement.clientWidth - 6) {
      left = Math.max(6, a.left);
      top = Math.max(a.bottom, ...fields.filter((f) => f.top < a.bottom && f.bottom > a.top).map((f) => f.bottom)) + 8;
    }
    const L = Math.round(left + window.scrollX) + 'px';
    const T = Math.round(top + window.scrollY) + 'px';
    if (chip.style.left !== L) chip.style.left = L;
    if (chip.style.top !== T) chip.style.top = T;
  }

  // Opgavekortet (den hvide boks) omkring spørgsmålet: yderste forælder
  // der er smallere end siden og har baggrund eller skygge.
  function cardBox() {
    const q = qNode();
    if (!q) return null;
    const vw = document.documentElement.clientWidth;
    let styled = null, narrow = null;
    for (let p = q.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
      const r = p.getBoundingClientRect();
      if (r.width < 300 || r.width >= vw - 40) continue;
      narrow = r;
      const cs = getComputedStyle(p);
      const bg = cs.backgroundColor;
      const hasBg = bg && bg !== 'transparent' && !/rgba\(\s*\d+,\s*\d+,\s*\d+,\s*0\s*\)/.test(bg);
      if (hasBg || (cs.boxShadow && cs.boxShadow !== 'none')) styled = r;
    }
    return styled || narrow;
  }

  function positionCard(chip) {
    const vw = document.documentElement.clientWidth;
    const box = cardBox() || { top: 0, right: vw };
    // Ikonets midte sidder 74px fra boksens højre kant og 18px under dens top
    // (målt efter skærmbillede, så det lander mellem den blå linje og toppen).
    // Når svaret er åbent, bliver højre kant stående, så det vokser mod venstre.
    const iconW = (parseFloat(getComputedStyle(chip).fontSize) || 20) * 2.09;
    const L = Math.round(box.right - 74 + iconW / 2 - chip.offsetWidth + window.scrollX) + 'px';
    const T = Math.round(box.top + 18 - chip.offsetHeight / 2 + window.scrollY) + 'px';
    if (chip.style.left !== L) chip.style.left = L;
    if (chip.style.top !== T) chip.style.top = T;
  }

  function positionCustom(chip) {
    const p = settings.positions[SITE];
    const vw = document.documentElement.clientWidth;
    const box = cardBox() || { top: 0, right: vw };
    // ikke ud over kanten, heller ikke når svaret er åbent og ikonet bliver bredere
    const maxL = window.scrollX + vw - chip.offsetWidth - 4;
    const L = Math.round(Math.max(window.scrollX + 2, Math.min(box.right + p.dx + window.scrollX, maxL))) + 'px';
    const T = Math.round(Math.max(window.scrollY + 2, box.top + p.dy + window.scrollY)) + 'px';
    if (chip.style.left !== L) chip.style.left = L;
    if (chip.style.top !== T) chip.style.top = T;
  }

  // Træk ikonet hen, hvor du vil have det. Når du giver slip, gemmes pladsen
  // (målt fra den hvide boks), og flytte-tilstanden slukkes.
  function startDrag(chip, e) {
    if (e.button !== 0) return;
    const r = chip.getBoundingClientRect();
    const gx = e.clientX - r.left;
    const gy = e.clientY - r.top;
    dragging = true;
    chip.setPointerCapture(e.pointerId);
    chip.style.right = 'auto';
    chip.style.bottom = 'auto';
    const move = (ev) => {
      chip.style.left = Math.round(ev.clientX - gx + window.scrollX) + 'px';
      chip.style.top = Math.round(ev.clientY - gy + window.scrollY) + 'px';
    };
    const end = () => {
      chip.removeEventListener('pointermove', move);
      chip.removeEventListener('pointerup', end);
      chip.removeEventListener('pointercancel', end);
      dragging = false;
      dragEndedAt = Date.now();
      const box = cardBox() || { top: 0, right: document.documentElement.clientWidth };
      const rr = chip.getBoundingClientRect();
      const positions = { ...(settings.positions || {}), [SITE]: { dx: Math.round(rr.left - box.right), dy: Math.round(rr.top - box.top) } };
      chrome.storage.local.set({ positions, position: 'custom', moving: false });
    };
    chip.addEventListener('pointermove', move);
    chip.addEventListener('pointerup', end);
    chip.addEventListener('pointercancel', end);
  }

  // Rigtig/forkert: sammenlign det, der står i feltet, med det beregnede svar
  const numOf = (s) => {
    const t = s.replace(/[−–—]/g, '-').replace(/°$/, '').replace(/\s+/g, '').replace(',', '.');
    const f = /^(-?\d+(?:\.\d+)?)\/(\d+(?:\.\d+)?)$/.exec(t);
    if (f) return +f[1] / +f[2];
    return /^-?(?:\d+\.?\d*|\.\d+)$/.test(t) ? parseFloat(t) : NaN;
  };
  const numsIn = (s) =>
    (s.replace(/[−–—]/g, '-').replace(/(\d),(\d)/g, '$1.$2').match(/-?\d+(?:\.\d+)?/g) || []).map(parseFloat);

  function isRight(ans, kind, typed) {
    if (kind === 'poly') {
      try { return reduceText(typed) === ans; } catch (e) { return false; }
    }
    if (/^(Alle|Ingen)/.test(ans)) {
      return typed.toLowerCase().replace(/\s+/g, '') === ans.toLowerCase().replace(/\s+/g, '');
    }
    if (kind === 'eq') {
      const roots = ans.split(/\s+eller\s+/).map((p) => p.replace(/^[a-z]\s*=\s*/i, ''));
      const got = numsIn(typed);
      return got.length === roots.length && roots.every((r) => {
        const tol = r.startsWith('≈') ? 0.01 : 1e-6;
        const v = numOf(r.replace('≈', ''));
        return got.some((g) => Math.abs(g - v) <= tol);
      });
    }
    const v = numOf(ans);
    const t = numOf(typed);
    if (isNaN(v) || isNaN(t)) return false;
    return Math.abs(t - v) <= (Number.isInteger(v) ? 1e-9 : 0.005);
  }

  function verdict(chip) {
    const box = answerBox();
    const typed = box && typeof box.value === 'string' ? box.value.trim() : '';
    if (!typed) return 'Skriv et svar';
    return isRight(chip._ans, chip._kind, typed) ? '✓ Rigtigt' : '✕ Forkert';
  }

  function desiredMode() {
    if (settings.position === 'custom' && settings.positions && settings.positions[SITE]) return 'custom';
    if (settings.position === 'card') return 'card';
    // Ved svarfeltet; hjørnet af skærmen bruges kun hvis svarfeltet ikke findes
    return inlineAnchor() ? 'inline' : 'tr';
  }

  function build() {
    const chip = document.createElement('div');
    chip.id = CHIP_ID;
    chip.dataset.site = SITE;
    chip.setAttribute('role', 'status');
    chip.setAttribute('aria-live', 'polite');
    const q = document.createElement('span');
    q.className = 'emat-q';
    const a = document.createElement('span');
    a.className = 'emat-a';
    const hint = document.createElement('span');
    hint.className = 'emat-hint';
    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '2');
    svg.setAttribute('stroke-linecap', 'round');
    svg.setAttribute('stroke-linejoin', 'round');
    ['M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5',
     'M9 18h6', 'M10 22h4'].forEach((d) => {
      const p = document.createElementNS(NS, 'path');
      p.setAttribute('d', d);
      svg.appendChild(p);
    });
    hint.appendChild(svg);
    chip.append(q, a, hint);
    chip.style.visibility = 'hidden';
    const swallow = (e) => { e.preventDefault(); e.stopPropagation(); };
    chip.addEventListener('mousedown', swallow, true);
    chip.addEventListener('pointerdown', swallow, true);
    chip.addEventListener('mouseup', swallow, true);
    chip.addEventListener('click', (e) => {
      swallow(e);
      if (settings.moving || Date.now() - dragEndedAt < 400) return;
      if (settings.hint) {    // hint-ikon <-> svar
        revealed = !revealed;
        clearTimeout(hideTimer);
        if (revealed && settings.check) {
          hideTimer = setTimeout(() => { revealed = false; tick(); }, 2500);
        }
        tick();
      }
    }, true);
    chip.addEventListener('pointerdown', (e) => { if (settings.moving) startDrag(chip, e); }, true);
    return chip;
  }

  // Vinkelopgaver med en tegning: tallene (fx "68°") står i figuren, ikke i spørgsmålet.
  // De bliver hængt på spørgsmålet som en ekstra linje "#68° 101°".
  const ANGLE_Q = /mangl\w*\s+vinkel/i;
  const ANGLE_LABEL = /^(\d{1,3}(?:[.,]\d+)?)\s*°$/;

  function angleLabels(qEl, raw) {
    const root = qEl.closest('td') || document.body;
    const t = ANGLE_Q.test(raw) ? raw + ' ' + root.innerText : root.innerText;
    if (!ANGLE_Q.test(t) || !/trekant/i.test(t)) return null;
    const hits = [];
    for (const el of root.querySelectorAll('div,span,p,td,th,font,b,i,label,text')) {
      if (el.textContent.length > 12 || el.closest('#' + CHIP_ID)) continue;
      const m = ANGLE_LABEL.exec(el.textContent.trim());
      if (m && isVisible(el) && getComputedStyle(el).visibility === 'visible') hits.push([el, m[1]]);
    }
    // kun det inderste element, hvis flere ligger i hinanden
    return hits.filter(([el]) => !hits.some(([o]) => o !== el && el.contains(o))).map((h) => h[1] + '°');
  }

  function fill(chip, raw) {
    const q = chip.querySelector('.emat-q');
    const a = chip.querySelector('.emat-a');
    q.textContent = prettyQuestion(raw);

    chip.style.visibility = 'hidden';

    const fail = () => {
      chip.dataset.state = 'error';
      a.textContent = 'Kan ikke regne denne opgavetype';
    };
    const ok = (text, kind) => { chip.dataset.state = 'ok'; chip._ans = text; chip._kind = kind || 'num'; a.textContent = text; };

    const va = /\n#(.*)$/.exec(raw);
    if (va) {
      const nums = (va[1].match(/\d+(?:[.,]\d+)?/g) || []).map((n) => parseFloat(n.replace(',', '.')));
      if (nums.length !== 2) {
        chip.dataset.state = 'error';
        a.textContent = 'Kan ikke aflæse vinklerne i tegningen';
        return;
      }
      const rest = 180 - nums[0] - nums[1];
      return rest > 0 ? ok(fmt(rest)) : fail();
    }

    if (parseFarv(raw)) { ok('…'); return; }

    const af = parseFractionOf(raw);
    if (af) {
      if (!af.den) return fail();
      return ok(fmt((af.num / af.den) * af.of));
    }

    const pct = parsePercentOf(raw);
    if (pct) return ok(fmt((pct.pct / 100) * pct.of));

    if (REDUCE_KEY.test(raw)) {
      try { return ok(reduceText(raw), 'poly'); } catch (e) {}
    }

    try {
      const r = solveText(raw);
      ok(r.text, r.kind);
    } catch (e) {
      try { ok(reduceText(raw), 'poly'); } catch (e2) { fail(); }
    }
  }

  let filledFor = null;
  let nextTimer = 0;
  let nextPending = null;
  let lastNextAt = 0;

  function setFieldValue(el, value) {
    const proto = Object.getPrototypeOf(el);
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, value); else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
  }

  function findNextButton(box) {
    const br = box.getBoundingClientRect();
    const cands = Array.from(document.querySelectorAll(
      'button, input[type=button], input[type=submit], input[type=image], a, [role=button]'
    )).filter((el) => !el.closest('#' + CHIP_ID) && reallyVisible(el));
    let best = null, bestD = Infinity;
    for (const el of cands) {
      const r = el.getBoundingClientRect();
      if (r.top < br.bottom - 4) continue;
      if (r.right < br.left || r.left > br.right) continue;
      if (((el.innerText || el.value || '') + '').toLowerCase().includes('afslut')) continue;
      const d = r.top - br.bottom;
      if (d < 250 && d < bestD) { best = el; bestD = d; }
    }
    return best;
  }

  function findNextByName() {
    const cands = Array.from(document.querySelectorAll(
      'button, input[type=button], input[type=submit], input[type=image], a, [role=button]'
    )).filter((el) => !el.closest('#' + CHIP_ID) && reallyVisible(el));
    return cands.find((el) => /n(æ|ae)ste|next/i.test(
      [el.id, el.name, el.title, el.alt, el.value, el.src, el.getAttribute('aria-label')].join(' ')
    )) || null;
  }

  function isLastQuestion(box) {
    if (SITE !== 'emat1') return false;
    const nums = Array.from(document.querySelectorAll('a[id^="Spg"]')).filter((a) => /^Spg\d+$/.test(a.id));
    const cur = nums.find((a) => /igang/.test(a.className));
    if (cur) return +cur.id.slice(3) === Math.max(...nums.map((a) => +a.id.slice(3)));
    const texts = [document.body ? document.body.innerText : ''];
    try { if (window.top !== window) texts.push(window.top.document.body.innerText); } catch (e) {}
    for (const t of texts) {
      const m = /(?:opgave|spørgsmål|spg\.?)\s*(\d+)\s*(?:af|\/)\s*(\d+)/i.exec(t);
      if (m) return +m[1] >= +m[2];
    }
    const btn = findNextButton(box);
    const label = btn ? [btn.innerText, btn.value, btn.title, btn.alt].join(' ') : '';
    return /færdig|aflever|resultat|indsend/i.test(label);
  }

  function pressNext(box) {
    const btn = (SITE === 'emat1' && document.querySelector('a[onclick*="SkiftSpg(-1)"]')) ||
      findNextButton(box) || findNextByName();
    if (btn) { btn.click(); return; }
    const target = document.activeElement || document.body;
    ['keydown', 'keyup'].forEach((type) => {
      target.dispatchEvent(new KeyboardEvent(type, {
        key: ' ', code: 'Space', keyCode: 32, which: 32, bubbles: true, cancelable: true
      }));
    });
  }

  const nextDelayMs = () =>
    Math.round(Math.min(2, Math.max(0.01, Number(settings.nextDelay) || 1)) * 1000);

  function disarmPending() {
    if (nextPending && nextPending.obs) nextPending.obs.disconnect();
    nextPending = null;
  }
  function armPending(raw, el) {
    disarmPending();
    const p = { raw, el, t: Date.now(), mut: false, obs: null };
    if (el) {
      p.obs = new MutationObserver(() => { p.mut = true; });
      p.obs.observe(el, { childList: true, characterData: true, subtree: true, attributes: true });
    }
    nextPending = p;
  }

  function autoFill(chip, raw) {
    if (!autoOn()) return;

    if (nextPending) {
      const p = nextPending;
      const unchanged = p.raw === raw && p.el === qNode() && !p.mut;
      if (unchanged && Date.now() - p.t < 1500) return;
      disarmPending();
    }

    if (chip.dataset.state !== 'ok') return;
    let text = (chip._ans || '').trim();
    const eq = /^[a-z] = ((?:≈ )?.*)$/.exec(text);
    if (eq && !eq[1].startsWith('≈')) text = eq[1];

    if (!text || text.length > 50) return;

    const box = answerBox();
    if (!box || box.isContentEditable || box.readOnly || box.disabled) return;

    // Hvis feltet er tomt, så skriv svaret. Hvis svaret allerede står der, fortsæt direkte til at trykke næste!
    if (box.value === '') {
      setFieldValue(box, text);
    } else if (box.value !== text) {
      return;
    }

    filledFor = raw;

    const delay = nextDelayMs();
    const now = performance.now();
    const first = !lastNextAt || now - lastNextAt > delay + 3000;
    const due = Math.max(now, first ? now + delay : lastNextAt + delay);

    const press = () => {
      if (!settings.enabled || !autoOn()) return;
      if (lastQuestion !== raw) return;
      const b = answerBox();
      if (!b || (b.value !== text && b.value !== '')) return;
      if (isLastQuestion(b)) return;
      lastNextAt = due;
      filledFor = null;
      armPending(raw, qNode());
      pressNext(b);
    };

    clearTimeout(nextTimer);
    if (due - now <= 0) press();
    else nextTimer = setTimeout(press, due - now);
  }

  // Vinkelmåler (emat1.dk): ét håndtag i stedet for de to drejeknapper.
  // Hold og træk rundt om vinkelmåleren for at dreje den. Den flytter sig ikke.
  const KNOB_STEP = 2; // grader pr. klik på sidens egen drejeknap

  function buildKnob() {
    const h = document.createElement('div');
    h.id = KNOB_ID;
    let last = null;
    let acc = 0;
    const angle = (e) => {
      const r = h.parentNode.getBoundingClientRect();
      return Math.atan2(e.clientY - (r.top + r.height / 2), e.clientX - (r.left + r.width / 2)) * 180 / Math.PI;
    };
    // så vinkelmåleren (jQuery UI draggable) ikke selv begynder at flytte sig
    ['mousedown', 'touchstart'].forEach((t) => h.addEventListener(t, (e) => {
      e.preventDefault();
      e.stopPropagation();
    }));
    h.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      h.setPointerCapture(e.pointerId);
      last = angle(e);
      acc = 0;
      h.classList.add('drag');
    });
    h.addEventListener('pointermove', (e) => {
      if (last === null) return;
      const a = angle(e);
      let d = a - last;
      if (d > 180) d -= 360;
      else if (d < -180) d += 360;
      last = a;
      acc += d;
      let n = Math.trunc(acc / KNOB_STEP);
      if (!n) return;
      acc -= n * KNOB_STEP;
      n = Math.max(-60, Math.min(60, n));
      const btn = document.getElementById(n > 0 ? 'Button_RoterVinkelMMinus' : 'Button_RoterVinkelM');
      if (btn) for (let i = 0; i < Math.abs(n); i++) btn.click();
    });
    const end = () => { last = null; h.classList.remove('drag'); };
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach((t) => h.addEventListener(t, end));
    return h;
  }

  function updateKnob() {
    const left = document.getElementById('Button_RoterVinkelM');
    const right = document.getElementById('Button_RoterVinkelMMinus');
    let h = document.getElementById(KNOB_ID);
    const ok = settings.enabled && left && right && left.parentNode === right.parentNode && isVisible(left) && isVisible(right);
    if (!ok) {
      if (h) h.remove();
      [left, right].forEach((a) => { if (a && a.style.pointerEvents === 'none') a.style.pointerEvents = ''; });
      return;
    }
    [left, right].forEach((a) => { if (a.style.pointerEvents !== 'none') a.style.pointerEvents = 'none'; });
    if (!h || h.parentNode !== left.parentNode) {
      if (h) h.remove();
      h = buildKnob();
      left.parentNode.appendChild(h);
    }
    const box = {
      left: Math.min(left.offsetLeft, right.offsetLeft),
      top: Math.min(left.offsetTop, right.offsetTop),
      right: Math.max(left.offsetLeft + left.offsetWidth, right.offsetLeft + right.offsetWidth),
      bottom: Math.max(left.offsetTop + left.offsetHeight, right.offsetTop + right.offsetHeight)
    };
    const css = {
      left: box.left + 'px', top: box.top + 'px',
      width: (box.right - box.left) + 'px', height: (box.bottom - box.top) + 'px'
    };
    for (const k in css) if (h.style[k] !== css[k]) h.style[k] = css[k];
  }

  function tick() {
    updateKnob();
    const qEl = qNode();
    let raw = qEl ? qEl.innerText.trim() : '';
    const lab = raw ? angleLabels(qEl, raw) : null;
    if (lab) raw += '\n#' + lab.join(' ');
    let chip = document.getElementById(CHIP_ID);

    if (!settings.enabled || !raw) {
      if (chip) chip.remove();
      clearOverlay();
      lastQuestion = null;
      revealed = false;
      revealedFor = null;
      filledFor = null;
      disarmPending();
      lastNextAt = 0;
      clearTimeout(nextTimer);
      return;
    }

    ensureStyle();
    const mode = desiredMode();

    if (chip && chip.dataset.mode !== mode) { chip.remove(); chip = null; }
    if (!chip) {
      chip = build();
      chip.dataset.mode = mode;
      document.documentElement.appendChild(chip);
      lastQuestion = null;
    }

    // Ny opgave -> tilbage til hint-ikonet
    if (revealedFor !== raw) { revealed = false; revealedFor = raw; }
    const hintOn = !!settings.hint;
    const shown = !hintOn || revealed;
    const rv = shown ? '1' : '0';
    const hv = hintOn ? '1' : '0';
    if (chip.dataset.reveal !== rv) chip.dataset.reveal = rv;
    if (chip.dataset.hint !== hv) chip.dataset.hint = hv;
    const what = settings.check ? 'rigtig/forkert' : 'svaret';
    const ttl = hintOn ? (revealed ? 'Klik for at skjule ' + what : 'Klik for at se ' + what) : '';
    const mv = settings.moving ? '1' : '0';
    if (chip.dataset.moving !== mv) chip.dataset.moving = mv;
    if (chip.title !== ttl) chip.title = ttl;

    const size = currentSize();
    if (chip.dataset.size !== size) chip.dataset.size = size;
    const hex = (c, d) => (/^#[0-9a-f]{6}$/i.test(c) ? c : d);
    const bg = hex(settings.chipBg, DEFAULTS.chipBg);
    const ink = hex(settings.chipInk, DEFAULTS.chipInk);
    if (chip.style.getPropertyValue('--emat-bg') !== bg) chip.style.setProperty('--emat-bg', bg);
    if (chip.style.getPropertyValue('--emat-ink') !== ink) chip.style.setProperty('--emat-ink', ink);
    if (raw !== lastQuestion) {
      fill(chip, raw);
      lastQuestion = raw;
    }

    // Rigtig/forkert i stedet for svaret
    let vd = '';
    if (chip.dataset.state === 'ok') {
      const ansEl = chip.querySelector('.emat-a');
      const checking = settings.check && !parseFarv(raw);
      const want = checking ? verdict(chip) : chip._ans;
      if (ansEl.textContent !== want) ansEl.textContent = want;
      if (checking) vd = want.charAt(0) === '✓' ? 'ok' : want.charAt(0) === '✕' ? 'bad' : '';
    }
    if (chip.dataset.verdict !== vd) chip.dataset.verdict = vd;

    autoFill(chip, raw);

    const farv = parseFarv(raw);
    if (farv) updateFarv(chip, farv, shown);
    else clearOverlay();

    if (dragging) { /* ikonet følger musen */ }
    else if (mode === 'inline') positionInline(chip);
    else if (mode === 'card') positionCard(chip);
    else if (mode === 'custom') positionCustom(chip);
    reveal(chip);
  }

  function reveal(chip) {
    if (chip.style.visibility === 'visible') return;
    chip.style.animation = 'none';
    void chip.offsetWidth;
    chip.style.animation = '';
    chip.style.visibility = 'visible';
  }

  let raf = 0;
  const soon = () => {
    if (settings.enabled && autoOn()) { tick(); return; }
    if (raf) return;
    raf = requestAnimationFrame(() => { raf = 0; tick(); });
  };

  chrome.storage.local.get(DEFAULTS, (stored) => {
    settings = { ...DEFAULTS, ...stored };
    if (settings.moving) { settings.moving = false; chrome.storage.local.set({ moving: false }); }
    tick();
  });

  chrome.storage.onChanged.addListener((changes) => {
    for (const key in changes) {
      settings[key] = changes[key].newValue !== undefined ? changes[key].newValue : DEFAULTS[key];
    }
    if (changes.hint) revealed = false;
    filledFor = null;
    tick();
  });

  const ours = (node) => {
    const el = node && node.nodeType === 1 ? node : node && node.parentElement;
    return !!el && !!el.closest && !!el.closest('#' + CHIP_ID + ',#' + LAYER_ID + ',#' + STYLE_ID + ',#' + KNOB_ID);
  };
  new MutationObserver((records) => {
    if (records.some((r) => !ours(r.target))) soon();
  }).observe(document.documentElement, {
    subtree: true, childList: true, characterData: true,
    attributes: true, attributeFilter: ['style', 'class', 'hidden', 'src']
  });

  // H: slå extensionen fra/til. Ikke mens man skriver i et felt.
  document.addEventListener('keydown', (e) => {
    if (e.key.toLowerCase() !== 'h' || e.ctrlKey || e.metaKey || e.altKey || e.repeat) return;
    const t = e.target;
    if (t && (t.isContentEditable || /^(input|textarea|select)$/i.test(t.tagName))) return;
    chrome.storage.local.set({ enabled: !settings.enabled });
  }, true);

  // Esc stopper flytningen af ikonet; når man skriver i feltet, opdateres rigtig/forkert med det samme
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && settings.moving) chrome.storage.local.set({ moving: false });
  }, true);
  document.addEventListener('input', soon, true);

  window.addEventListener('resize', soon);
  window.addEventListener('scroll', soon, true);
  window.addEventListener('load', soon);
  setInterval(tick, 500);
})();