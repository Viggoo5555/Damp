const DEFAULTS = { enabled: true, hint: true, position: 'card', chipBg: '#ffe45c', chipInk: '#1b2a6b', check: true, moving: false, positions: {}, sizes: {}, autoDysten: false, nextDelay: 1 };

const SIZE_DEFAULTS = { dysten: 'l', emat1: 's', other: 'm' };
function siteKey(url) {
  try {
    const u = new URL(url);
    if (/\/dysten(\/|$)/i.test(u.pathname)) return 'dysten';
    if (/(^|\.)emat1\.dk$/i.test(u.hostname)) return 'emat1';
  } catch (e) {}
  return 'other';
}
let site = 'other';
const currentSize = () => (state.sizes && state.sizes[site]) || SIZE_DEFAULTS[site];

const POS_NAMES = {
  inline: 'Ved svarfeltet',
  card: 'Øverst til højre i opgaven',
  custom: 'Egen placering'
};

const enabledEl = document.getElementById('enabled');
const statusEl = document.getElementById('status');
const optionsEl = document.getElementById('options');
const posNameEl = document.getElementById('pos-name');
const autoDystenEl = document.getElementById('auto-dysten');
const delayEl = document.getElementById('nextdelay');
const delayValEl = document.getElementById('delay-val');
const moveBtn = document.getElementById('move-btn');
const colorBtn = document.getElementById('color-btn');
const colorPanel = document.getElementById('color-panel');
const bgEl = document.getElementById('chip-bg');
const inkEl = document.getElementById('chip-ink');

let state = { ...DEFAULTS };

function render() {
  enabledEl.checked = state.enabled;
  optionsEl.disabled = !state.enabled;
  statusEl.textContent = state.enabled
    ? (state.hint
      ? 'Tryk på pæren på opgavesiden for at se ' + (state.check ? 'om dit svar er rigtigt.' : 'svaret.')
      : (state.check ? 'Du får at vide, om dit svar er rigtigt.' : 'Svaret vises på opgavesiden.'))
    : 'Slået fra – der vises ikke noget svar.';

  const content = document.querySelector('input[name="content"][value="' + (state.check ? 'check' : 'answer') + '"]');
  if (content) content.checked = true;

  const mode = document.querySelector('input[name="mode"][value="' + (state.hint ? 'hint' : 'answer') + '"]');
  if (mode) mode.checked = true;

  const posKey = state.position === 'card' ? 'card' : state.position === 'custom' ? 'custom' : 'inline';
  document.querySelectorAll('input[name="pos"]').forEach((r) => { r.checked = r.value === posKey; });
  moveBtn.textContent = state.moving ? 'Stop flytning' : 'Flyt ikonet';
  moveBtn.setAttribute('aria-pressed', String(!!state.moving));
  posNameEl.textContent = POS_NAMES[posKey];
  const size = document.querySelector('input[name="size"][value="' + currentSize() + '"]');
  if (size) size.checked = true;

  colorBtn.style.background = state.chipBg;
  colorBtn.style.borderColor = state.chipInk;
  bgEl.value = state.chipBg;
  inkEl.value = state.chipInk;
  document.querySelectorAll('.preset').forEach((b) => {
    b.setAttribute('aria-pressed', String(b.dataset.bg === state.chipBg && b.dataset.ink === state.chipInk));
  });

  autoDystenEl.checked = !!state.autoDysten;

  const d = Math.round(Math.min(2, Math.max(0.01, Number(state.nextDelay) || 1)) * 100) / 100;
  delayEl.value = d;
  delayValEl.textContent = d.toFixed(2).replace('.', ',') + ' s';
}

function save(patch) {
  state = { ...state, ...patch };
  chrome.storage.local.set(patch);
  render();
}

function init() {
  chrome.storage.local.get(DEFAULTS, (stored) => {
    state = { ...DEFAULTS, ...stored };
    render();
  });
}
try {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    site = siteKey(tabs && tabs[0] && tabs[0].url);
    init();
  });
} catch (e) {
  init();
}

enabledEl.addEventListener('change', () => save({ enabled: enabledEl.checked }));

document.querySelectorAll('input[name="pos"]').forEach((el) => {
  el.addEventListener('change', () => { if (el.checked) save({ position: el.value }); });
});
document.querySelectorAll('input[name="mode"]').forEach((el) => {
  el.addEventListener('change', () => { if (el.checked) save({ hint: el.value === 'hint' }); });
});
document.querySelectorAll('input[name="size"]').forEach((el) => {
  el.addEventListener('change', () => { if (el.checked) save({ sizes: { ...state.sizes, [site]: el.value } }); });
});

moveBtn.addEventListener('click', () => {
  if (state.moving) { save({ moving: false }); return; }
  state = { ...state, moving: true };
  chrome.storage.local.set({ moving: true }, () => window.close());
});
document.querySelectorAll('input[name="content"]').forEach((el) => {
  el.addEventListener('change', () => { if (el.checked) save({ check: el.value === 'check' }); });
});

colorBtn.addEventListener('click', () => {
  colorPanel.hidden = !colorPanel.hidden;
  colorBtn.setAttribute('aria-expanded', String(!colorPanel.hidden));
});
document.querySelectorAll('.preset').forEach((b) => {
  b.addEventListener('click', () => save({ chipBg: b.dataset.bg, chipInk: b.dataset.ink }));
});
bgEl.addEventListener('input', () => save({ chipBg: bgEl.value }));
inkEl.addEventListener('input', () => save({ chipInk: inkEl.value }));

autoDystenEl.addEventListener('change', () => save({ autoDysten: autoDystenEl.checked }));
delayEl.addEventListener('input', () => save({ nextDelay: Math.round(parseFloat(delayEl.value) * 100) / 100 }));