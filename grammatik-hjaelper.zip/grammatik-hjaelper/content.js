/* Grammatik Hjælper – komma-opgaver på grammatip.com (/exercise/page/...)
 *
 * Siden indeholder ikke selve svaret, så hjælpen bygger på enkle regler:
 *  1) Helsætninger: komma foran og/men/eller/så/for, når der efter ordet begynder en ny
 *     helsætning (nyt grundled + eget udsagnsord). Samme grundled = intet komma.
 *  2) Ledsætninger: komma foran at/fordi/hvis/når/mens/… når ledsætningen kommer efter hovedsætningen.
 *  3) Ejefald/flertal (valgopgaver og skriv-selv): svaret afgøres af den danske sætning (se solveEjefald/solveWrite).
 */

/* ======================= Regler (kan testes uden browser) ======================= */

const CONJ = new Set(['og', 'men', 'eller', 'så', 'for']);

// Ledsætnings-ord. SUB_VERB: nyt grundled kan være et navneord (vi leder efter udsagnsord).
// SUB_SUBJ: tæller kun med et tydeligt grundled (pronomen) lige efter – ordene kan ellers være forholdsord.
const SUB_VERB = new Set(['at', 'fordi', 'hvis', 'når', 'selvom', 'mens', 'indtil', 'medmindre', 'hvorfor', 'hvordan', 'hvornår', 'eftersom']);
const SUB_SUBJ = new Set(['da', 'før', 'inden']);

// Ord der typisk er grundled i en ny sætning. ("i" er med vilje udeladt: det er oftest et forholdsord.)
const SUBJ = new Set(['jeg', 'du', 'han', 'hun', 'den', 'det', 'vi', 'de', 'man', 'der']);

const VERBS = new Set([
  'er', 'var', 'har', 'havde', 'blev', 'bliver', 'kom', 'kommer', 'gik', 'går',
  'tog', 'tager', 'gav', 'giver', 'sad', 'sidder', 'lå', 'ligger', 'stod', 'står',
  'sagde', 'siger', 'ser', 'løb', 'løber', 'fik', 'får', 'ved', 'vidste',
  'kan', 'kunne', 'vil', 'ville', 'skal', 'skulle', 'må', 'måtte', 'bør', 'burde',
  'gør', 'gjorde', 'bor', 'vandt', 'vinder', 'fandt', 'finder', 'spiste', 'spiser',
  'læste', 'læser', 'rejste', 'rejser', 'lyste', 'bad', 'ringer', 'sov', 'sover',
  'drak', 'drikker', 'skrev', 'skriver', 'hed', 'hedder', 'mente', 'mener',
  'synes', 'syntes', 'ejer', 'ejede', 'køber', 'købte', 'sælger', 'solgte',
  'elsker', 'hjælper', 'lever', 'levede', 'bruger', 'brugte', 'kører', 'kørte',
  'tror', 'tænker', 'håber', 'ønsker', 'føler', 'ligner', 'betyder', 'mangler'
]);

// Ord på -te/-ede, der ikke er udsagnsord
const NOT_VERB = new Set(['tante', 'gate', 'rute', 'pointe', 'sidste', 'næste', 'første', 'bedste']);

function normalise(w) {
  return String(w).toLowerCase().replace(/[.,;:!?"“”„()]/g, '');
}

function isVerb(w) {
  if (!w || NOT_VERB.has(w)) return false;
  if (VERBS.has(w)) return true;
  if (/^[a-zæøå]{3,}(ede|dt)$/.test(w)) return true;                       // byggede, vandt
  if (/^[a-zæøå]{2,}te$/.test(w) && !/ste$/.test(w)) return true;          // kørte, tænkte
  return false;
}

function judge(norm, words, i) {
  const conj = norm[i];
  const next = norm[i + 1];
  if (!next) return { comma: false };

  if (SUBJ.has(next)) {
    return {
      comma: true,
      reason: `«${conj}» binder to helsætninger sammen. Efter «${conj}» kommer et nyt grundled («${words[i + 1]}»), så der skal komma foran «${conj}».`
    };
  }

  // «så» og «for» tæller kun som bindeord med et tydeligt nyt grundled
  if (conj === 'så' || conj === 'for') return { comma: false };

  for (let k = i + 1; k <= Math.min(i + 4, norm.length - 1); k++) {
    if (!isVerb(norm[k])) continue;
    if (k === i + 1) {
      if (conj === 'men') {
        return {
          comma: true,
          reason: `Foran «men» sætter man normalt komma, når den indleder et nyt udsagn («${words[k]}»).`
        };
      }
      return {
        comma: false,
        note: `«${conj}» står lige foran udsagnsordet «${words[k]}». Det er det samme grundled, der fortsætter, så der skal ikke komma.`
      };
    }
    return {
      comma: true,
      reason: `Efter «${conj}» begynder en ny helsætning («${words.slice(i + 1, k + 1).join(' ')}») med eget udsagnsord, så der skal komma foran «${conj}».`
    };
  }

  return {
    comma: false,
    note: `«${conj}» binder bare ord eller led sammen og ikke to helsætninger, så der skal ikke komma.`
  };
}

function judgeSub(norm, words, i) {
  const conj = norm[i];
  const next = norm[i + 1];
  if (!next) return { comma: false };
  let ok = SUBJ.has(next);
  if (!ok && SUB_VERB.has(conj)) {
    for (let k = i + 1; k <= Math.min(i + 4, norm.length - 1); k++) {
      if (isVerb(norm[k])) { ok = true; break; }
    }
  }
  if (!ok) return { comma: false };
  return {
    comma: true,
    reason: `«${conj}» indleder en ledsætning. Kommer ledsætningen efter hovedsætningen, skal der komma foran «${conj}».`
  };
}

// words: sætningens ord (uden nummeret). Returnerer { commas: [{after, reason}], notes: [] }
function analyse(words) {
  const norm = words.map(normalise);
  const commas = [];
  const notes = [];
  for (let i = 2; i < norm.length; i++) {
    const w = norm[i];
    const coord = CONJ.has(w);
    const sub = SUB_VERB.has(w) || SUB_SUBJ.has(w);
    if (!coord && !sub) continue;
    if (CONJ.has(norm[i - 1])) continue;
    if (/,$/.test(words[i - 1])) continue;
    if (coord && !norm.slice(0, i).some(isVerb)) continue;   // der skal først være en helsætning
    const r = coord ? judge(norm, words, i) : judgeSub(norm, words, i);
    if (r.comma) commas.push({ after: i - 1, reason: r.reason });
    else if (r.note) notes.push(r.note);
  }
  return { commas, notes };
}

/* ---- Valgopgaver: ejefald/ental/flertal (the boy's / the boys / the boys') ----
 * Den danske sætning afgør formen: -ernes/-enes = flertal + ejefald (s'), -s = ental + ejefald ('s),
 * ellers er det bare flertal (s). Kun til opgaver, hvor svarmulighederne har apostrof-former.
 */

// Danske ord på -s, der ikke er navneord i ejefald
const NOT_GEN = new Set(['hans', 'hendes', 'deres', 'vores', 'jeres', 'ellers', 'dags', 'mens', 'undervejs', 'tværs', 'fælles']);

function danishCase(danish) {
  const words = String(danish || '').split(/\s+/).map(normalise).filter(Boolean);
  if (!words.length) return null;
  for (const w of words) if (/^[a-zæøå]{3,}(ernes|enes)$/.test(w)) return { kind: 'pluralPoss', word: w };
  for (const w of words) if (!NOT_GEN.has(w) && /^[a-zæøå]{3,}s$/.test(w)) return { kind: 'singPoss', word: w };
  return { kind: 'plural', word: '' };
}

// Returnerer { pick, reason } eller null, hvis opgaven ikke ligner en ejefald-opgave eller svaret er uklart
function solveEjefald(danish, opts) {
  if (opts.filter((o) => /'/.test(o)).length < 2) return null;
  const c = danishCase(danish);
  if (!c) return null;
  const re = { pluralPoss: /s'$/, singPoss: /[^s]'s$/, plural: /^[^']+s$/ }[c.kind];
  const hits = [];
  opts.forEach((o, i) => { if (re.test(o)) hits.push(i); });
  if (hits.length !== 1) return null;
  return { pick: hits[0], text: opts[hits[0]], reason: reasonOf(c) };
}

function reasonOf(c) {
  return {
    pluralPoss: `«${c.word}» er flertal og ejer noget, så apostroffen står efter s.`,
    singPoss: `«${c.word}» er ental og ejer noget, så der skal 's.`,
    plural: 'Ingen ejefald i den danske sætning, så det er bare flertal: s uden apostrof.'
  }[c.kind];
}

/* ---- Skriv-selv-opgaver: ordet i parentesen sættes i den form, den danske sætning kræver ---- */

const IRREGULAR = {
  child: 'children', man: 'men', woman: 'women', foot: 'feet', tooth: 'teeth', goose: 'geese', mouse: 'mice',
  person: 'people', ox: 'oxen', sheep: 'sheep', fish: 'fish', deer: 'deer', wife: 'wives', life: 'lives',
  knife: 'knives', wolf: 'wolves', leaf: 'leaves', half: 'halves', thief: 'thieves'
};

function pluralOf(w) {
  const l = w.toLowerCase();
  if (IRREGULAR[l]) return IRREGULAR[l];
  if (/(s|x|z|ch|sh)$/.test(l)) return w + 'es';
  if (/[^aeiou]y$/.test(l)) return w.slice(0, -1) + 'ies';
  return w + 's';
}

// Returnerer { text, reason } eller null, hvis der ikke står noget ord i parentesen
function solveWrite(danish, base) {
  const b = String(base || '').trim().split(/\s+/).pop();
  if (!b) return null;
  const c = danishCase(danish);
  if (!c) return null;
  const pl = pluralOf(b);
  const text = { pluralPoss: /s$/.test(pl) ? pl + "'" : pl + "'s", singPoss: b + "'s", plural: pl }[c.kind];
  return { text, reason: reasonOf(c) };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { analyse, isVerb, normalise, solveEjefald, solveWrite, pluralOf };
}

/* ======================= Siden ======================= */

if (typeof document !== 'undefined' && typeof chrome !== 'undefined' && chrome.storage) {
  const DEFAULTS = {
    enabled: true, hint: true, explain: false, commaColor: '#7b8199', commaOpacity: 60, size: 'm'
  };
  const SCALE = { s: 1, m: 1.2, l: 1.5 };
  const ANS_SCALE = { s: 0.9, m: 1.05, l: 1.3 };

  let cfg = null;
  let open = false;
  let raf = 0;
  let root, bulb, panel;
  let commaEls = [];
  let ansEls = [];
  let panelSig = '';

  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  /* ---- Komma-opgaver ---- */
  function readLines() {
    const page = document.getElementById('page-content');
    if (!page) return [];
    const lines = [];
    for (const line of page.children) {
      const wraps = line.querySelectorAll('.punctuation-segment-wrapper');
      if (!wraps.length) continue;
      let items = [];
      wraps.forEach((w) => {
        const seg = w.querySelector('.punctuation-segment');
        if (!seg) return;
        const text = (seg.textContent || '').replace(/\u00a0/g, ' ').trim();
        if (text) items.push({ text, seg });
      });
      let num = String(lines.length + 1);
      if (items.length && /^\d+\.$/.test(items[0].text)) {
        num = items[0].text.replace('.', '');
        items = items.slice(1);
      }
      if (items.length) lines.push({ num, items });
    }
    return lines;
  }

  // Selve ordets tekst (uden det tomme felt til komma), så kommaet kan stå lige efter bogstaverne
  function wordRect(seg) {
    const tn = [...seg.childNodes].find((n) => n.nodeType === 3 && n.nodeValue.trim());
    if (!tn) return null;
    const r = document.createRange();
    r.selectNodeContents(tn);
    const rects = r.getClientRects();
    return rects.length ? rects[rects.length - 1] : null;
  }

  /* ---- Valgopgaver ---- */
  const PLACEHOLDER = /^(\?|-+|–|—|vælg.*|select.*|choose.*)$/i;
  const BLOCK = /^(DIV|P|LI|UL|OL|H[1-6]|TR|TABLE|FORM|SECTION|ARTICLE)$/;
  const tidy = (s) => s.replace(/[ \t\u00a0]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{2,}/g, '\n').trim();

  function formRoot() {
    return document.getElementById('exercise-form') || document.getElementById('steps') || document.getElementById('layout-main');
  }

  // Grammatip bruger egne menuer (.dropdown med .dropdown-item); andre sider almindelige <select>
  const isMenu = (n) => n.tagName === 'SELECT' || (n.classList && n.classList.contains('dropdown') && !!n.querySelector('.dropdown-item'));
  const menuOpts = (n) => (n.tagName === 'SELECT'
    ? [...n.options].map((o) => o.textContent.trim())
    : [...n.querySelectorAll('.dropdown-item')].map((o) => o.textContent.trim())
  ).filter((t) => t && !PLACEHOLDER.test(t));

  // Tekstfelter bruges kun på ejefald-siderne, så felterne til komma ikke forveksles med dem
  const ejefaldPage = () => /ejefald/i.test(((document.querySelector('h1.exercise-pages-header') || document.querySelector('h1') || {}).textContent) || '');
  const isBox = (n) => n.tagName === 'INPUT' && n.type === 'text' && ejefaldPage();

  // Den danske sætning står før "=" lige foran rullemenuen (på samme linje eller linjen over)
  function danishPart(before) {
    const ls = before.split('\n');
    const last = ls[ls.length - 1];
    const eq = last.indexOf('=');
    let d = '';
    if (eq > 0) d = last.slice(0, eq);
    else if (eq === 0) d = ls[ls.length - 2] || '';
    return d.replace(/^\s*\d+\.\s*/, '').trim();
  }

  function readSelects() {
    const form = formRoot();
    if (!form) return { form: null, items: [] };
    const sels = [...form.querySelectorAll('select, .dropdown, input')].filter((s) => (isMenu(s) || isBox(s)) && !(root && root.contains(s)));
    if (!sels.length) return { form, items: [] };

    // Fladt udtræk af teksten med rullemenuerne som markører
    const parts = [];
    (function walk(n) {
      if (n.nodeType === 3) { parts.push(n.nodeValue); return; }
      if (n.nodeType !== 1) return;
      const tag = n.tagName;
      if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT' || tag === 'OPTION') return;
      if (isMenu(n) || isBox(n)) { parts.push(n); return; }
      if (tag === 'BR') { parts.push('\n'); return; }
      const block = BLOCK.test(tag);
      if (block) parts.push('\n');
      n.childNodes.forEach(walk);
      if (block) parts.push('\n');
    })(form);

    const at = [];
    parts.forEach((p, i) => { if (typeof p !== 'string') at.push(i); });

    const items = [];
    at.forEach((idx, k) => {
      const sel = parts[idx];
      const box = isBox(sel);
      const opts = box ? null : menuOpts(sel);
      if (opts && opts.length < 2) return;
      const prev = k > 0 ? at[k - 1] : -1;
      const next = k < at.length - 1 ? at[k + 1] : parts.length;
      const before = tidy(parts.slice(prev + 1, idx).join(''));
      // Skriv-selv: ordet i parentesen står lige efter feltet
      const m = box ? tidy(parts.slice(idx + 1, next).join('')).match(/\(([^)]+)\)/) : null;
      items.push({ sel, n: k + 1, opts, danish: danishPart(before), base: m ? m[1] : '' });
    });
    return { form, items };
  }

  /* ---- Overlay ---- */
  function ensureRoot() {
    if (root) return;
    const style = document.createElement('style');
    style.id = 'emh-style';
    style.textContent = `
      #emh-root { position: fixed; inset: 0; pointer-events: none; z-index: 2147483000;
        font-family: "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif; }
      #emh-root .emh-comma { position: absolute; pointer-events: none; white-space: pre; font-weight: 700; }
      #emh-root .emh-ans { position: absolute; pointer-events: none; white-space: nowrap; font-weight: 600;
        transform: translateY(-50%); max-width: 260px; overflow: hidden; text-overflow: ellipsis; }
      #emh-root .emh-bulb { position: fixed; right: 24px; bottom: 104px; pointer-events: auto; cursor: pointer;
        width: 44px; height: 44px; border: 3px solid #1b2a6b; background: #ffe45c;
        border-radius: 50%; font-size: 22px; line-height: 1; padding: 0;
        box-shadow: 0 3px 12px rgba(0,0,0,.35); }
      #emh-root .emh-bulb:focus-visible { outline: 3px solid #fff; outline-offset: 2px; }
      #emh-root .emh-panel { position: fixed; right: 24px; bottom: 164px; width: 330px; max-height: 55vh;
        overflow: auto; pointer-events: auto; background: #fff; color: #161b33; border-radius: 14px;
        padding: 12px 14px; box-shadow: 0 8px 28px rgba(0,0,0,.35); font-size: 13.5px; line-height: 1.4; }
      #emh-root .emh-panel h2 { margin: 0 0 8px; font-size: 15px; }
      #emh-root .emh-panel h2 + ul + .foot + h2, #emh-root .emh-panel .foot + h2 { margin-top: 14px; }
      #emh-root .emh-panel ul { margin: 0; padding: 0; list-style: none; }
      #emh-root .emh-panel li { padding: 7px 0; border-top: 1px solid #dde1ee; }
      #emh-root .emh-panel li:first-child { border-top: 0; }
      #emh-root .emh-panel b { font-weight: 700; }
      #emh-root .emh-panel .why { display: block; margin-top: 2px; color: #5c647f; font-size: 12.5px; }
      #emh-root .emh-panel .err { margin: 0 0 8px; padding: 8px 10px; border-radius: 8px; background: #fdecea; color: #8a1c13; font-size: 12.5px; }
      #emh-root .emh-panel .foot { margin: 8px 0 0; padding-top: 8px; border-top: 1px solid #dde1ee;
        color: #5c647f; font-size: 12px; }
    `;
    document.head.appendChild(style);

    root = document.createElement('div');
    root.id = 'emh-root';
    bulb = document.createElement('button');
    bulb.type = 'button';
    bulb.className = 'emh-bulb';
    bulb.textContent = '💡';
    bulb.setAttribute('aria-label', 'Vis hjælp');
    bulb.addEventListener('click', () => { open = !open; schedule(); });
    panel = document.createElement('div');
    panel.className = 'emh-panel';
    root.append(bulb, panel);
    document.body.appendChild(root);
  }

  function pool(arr, n, cls) {
    while (arr.length < n) {
      const el = document.createElement('div');
      el.className = cls;
      root.appendChild(el);
      arr.push(el);
    }
    while (arr.length > n) arr.pop().remove();
  }

  function update() {
    if (!cfg) return;
    const lines = cfg.enabled ? readLines() : [];
    const commaRes = lines.map((ln) => ({ ln, res: analyse(ln.items.map((x) => x.text)) }));
    const sel = cfg.enabled ? readSelects() : { form: null, items: [] };
    const picks = sel.items.map((it) => ({ it, ans: it.opts ? solveEjefald(it.danish, it.opts) : solveWrite(it.danish, it.base) }));
    const show = cfg.enabled && (commaRes.length > 0 || picks.some((p) => p.ans));

    if (!show) { if (root) root.style.display = 'none'; return; }
    ensureRoot();
    root.style.display = '';

    const visible = !cfg.hint || open;
    bulb.style.display = cfg.hint ? '' : 'none';
    bulb.setAttribute('aria-pressed', String(open));
    const opacity = String(Math.min(100, Math.max(20, Number(cfg.commaOpacity) || 60)) / 100);

    // --- Spøgelses-kommaer
    const marks = [];
    commaRes.forEach((r) => r.res.commas.forEach((c) => { const it = r.ln.items[c.after]; if (it) marks.push(it); }));
    pool(commaEls, marks.length, 'emh-comma');
    const scale = SCALE[cfg.size] || 1.2;
    marks.forEach((it, i) => {
      const el = commaEls[i];
      const rc = wordRect(it.seg);
      if (!rc || !visible) { el.style.display = 'none'; return; }
      const cs = getComputedStyle(it.seg);
      el.style.display = '';
      if (el.textContent !== ',') el.textContent = ',';
      el.style.left = (rc.right + 0.5).toFixed(1) + 'px';
      el.style.top = rc.top.toFixed(1) + 'px';
      el.style.height = rc.height.toFixed(1) + 'px';
      el.style.lineHeight = rc.height.toFixed(1) + 'px';
      el.style.fontFamily = cs.fontFamily;
      el.style.fontSize = (parseFloat(cs.fontSize) * scale).toFixed(1) + 'px';
      el.style.color = cfg.commaColor;
      el.style.opacity = opacity;
    });

    // --- Svar i valgopgaver
    pool(ansEls, picks.length, 'emh-ans');
    const formRect = sel.form ? sel.form.getBoundingClientRect() : null;
    const ascale = ANS_SCALE[cfg.size] || 1.05;
    picks.forEach(({ it, ans }, i) => {
      const el = ansEls[i];
      const sr = it.sel.getBoundingClientRect();
      if (!visible || !ans || !sr.width) { el.style.display = 'none'; return; }
      el.style.display = '';
      const x = formRect ? Math.min(formRect.right + 10, window.innerWidth - 150) : sr.right + 150;
      el.style.left = Math.round(Math.max(x, sr.right + 8)) + 'px';
      el.style.top = Math.round(sr.top + sr.height / 2) + 'px';
      el.style.fontSize = (15 * ascale).toFixed(1) + 'px';
      el.style.color = cfg.commaColor;
      el.style.opacity = opacity;
      el.textContent = '← ' + ans.text;
    });

    // --- Forklaring
    const showPanel = visible && cfg.explain;
    panel.style.display = showPanel ? '' : 'none';
    if (showPanel) {
      let html = '';
      if (commaRes.length && cfg.explain) {
        const li = commaRes.map(({ ln, res }) => {
          const words = ln.items.map((x) => x.text);
          if (res.commas.length) {
            return res.commas.map((c) =>
              `<li><b>Linje ${esc(ln.num)}:</b> komma efter «${esc(words[c.after])}»<span class="why">${esc(c.reason)}</span></li>`
            ).join('');
          }
          const why = res.notes.length ? `<span class="why">${esc(res.notes[0])}</span>` : '';
          return `<li><b>Linje ${esc(ln.num)}:</b> ingen komma${why}</li>`;
        }).join('');
        html += `<h2>Hvor skal kommaet stå?</h2><ul>${li}</ul>` +
          `<p class="foot">Forslaget bygger på enkle regler og kan tage fejl. Tjek selv, at sætningen giver mening.</p>`;
      }
      if (picks.some((p) => p.ans)) {
        html += `<h2>Forslag til svar</h2>`;
        const li = picks.map(({ it, ans }) => {
          if (!ans) return '';
          return `<li><b>Opgave ${it.n}:</b> ${esc(ans.text)}</li>`;
        }).join('');
        html += `<ul>${li}</ul>`;
      }
      if (html !== panelSig) { panel.innerHTML = html; panelSig = html; }
    }
  }

  function schedule() {
    if (raf) return;
    raf = requestAnimationFrame(() => { raf = 0; try { update(); } catch (e) { /* siden skifter mens vi læser */ } });
  }

  function start() {
    const mo = new MutationObserver((records) => {
      if (root && records.every((r) => root.contains(r.target))) return;
      schedule();
    });
    mo.observe(document.body, { childList: true, subtree: true, characterData: true });
    window.addEventListener('scroll', schedule, true);
    window.addEventListener('resize', schedule);
    setInterval(schedule, 1000);
    schedule();
  }

  /* ---- Opgavens opbygning (til når en ny opgavetype skal understøttes) ---- */
  function buildDump() {
    const main = document.querySelector('#layout-main') || document.body;
    const clone = main.cloneNode(true);
    clone.querySelectorAll('script, style, svg, noscript, #emh-root').forEach((n) => n.remove());
    const html = clone.outerHTML.replace(/\s+/g, ' ').replace(/ data-v-[a-z0-9]+=""/g, '');
    const requests = [...new Set(
      performance.getEntriesByType('resource')
        .filter((r) => ['fetch', 'xmlhttprequest'].includes(r.initiatorType))
        .map((r) => r.name.split('?')[0])
    )].filter((u) => !/sentry|matomo|keep-alive|analytics/i.test(u));
    return {
      side: location.pathname.replace(/\d{5,}/g, '<id>'),
      titel: document.title,
      framework: {
        angularjs: !!document.querySelector('[ng-class], [ng-repeat], [ng-click], [ng-app]'),
        vue: !!document.querySelector('[data-v-app]')
      },
      antalRullemenuer: document.querySelectorAll('#layout-main select, #layout-main .dropdown').length,
      forespoergsler: requests,
      html: html.slice(0, 16000),
      afkortet: html.length > 16000
    };
  }

  try {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg && msg.type === 'emh-dump') { sendResponse(buildDump()); }
    });
    chrome.storage.local.get(DEFAULTS, (stored) => { cfg = { ...DEFAULTS, ...stored }; start(); });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !cfg) return;
      for (const k of Object.keys(changes)) cfg[k] = changes[k].newValue;
      schedule();
    });
  } catch (e) { /* extension genindlæst – prøv at opdatere siden */ }
}
