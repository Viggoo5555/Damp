/* Kører i sidens egen verden: tager en kopi af kald til /api/v1/exercises/ (også svar-kald) */
(() => {
  const store = [];
  const RE = /\/api\/v1\/exercises\//;
  function save(url, method, body, text) {
    try {
      if (!RE.test(url)) return;
      let d; try { d = JSON.parse(text); } catch (e) { d = String(text).slice(0, 2000); }
      const u = String(url).split('?')[0];
      const m = (method || 'GET').toUpperCase();
      const b = m === 'GET' ? '' : String(body == null ? '' : body).slice(0, 2000);
      const i = store.findIndex((x) => x.u === u && x.m === m && x.b === b);
      const e = { u, m, b, d, t: Date.now() };
      if (i >= 0) store[i] = e; else store.push(e);
      if (store.length > 60) store.shift();
      document.documentElement.setAttribute('data-emh-session', JSON.stringify(store));
    } catch (e) { /* ignorer */ }
  }
  const of = window.fetch;
  if (of) window.fetch = function (...a) {
    const p = of.apply(this, a);
    try {
      const u = typeof a[0] === 'string' ? a[0] : ((a[0] && a[0].url) || String(a[0] || ''));
      const o = a[1] || {};
      const m = o.method || (a[0] && a[0].method) || 'GET';
      if (RE.test(u)) p.then((r) => r.clone().text().then((t) => save(u, m, o.body, t))).catch(() => {});
    } catch (e) {}
    return p;
  };
  const xo = XMLHttpRequest.prototype.open;
  const xs = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__emhUrl = String(u); this.__emhM = m; return xo.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (body) {
    if (RE.test(this.__emhUrl || '')) {
      this.addEventListener('load', () => {
        try { save(this.__emhUrl, this.__emhM, body, this.responseType && this.responseType !== 'text' ? JSON.stringify(this.response) : this.responseText); } catch (e) {}
      });
    }
    return xs.apply(this, arguments);
  };
})();
