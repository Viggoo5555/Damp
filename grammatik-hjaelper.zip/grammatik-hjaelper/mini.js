/* Mini-missioner: finder det rigtige svar i opgavedata, markerer det og kan trykke på det. */
const MINI_KEYS_TEXT = ['text', 'label', 'value', 'content', 'title', 'answer', 'name', 'option'];
const MINI_FLAGS = ['correct', 'isCorrect', 'is_correct', 'right', 'isRight', 'is_right', 'valid', 'isValid', 'is_valid'];
const mNorm = (s) => String(s).trim().toLowerCase();

function mText(c) {
  if (typeof c === 'string') return c;
  if (c && typeof c === 'object') for (const k of MINI_KEYS_TEXT) if (typeof c[k] === 'string') return c[k];
  return null;
}
function mWalk(node, fn, depth) {
  depth = depth || 0;
  if (node == null || depth > 14 || typeof node !== 'object') return;
  fn(node);
  (Array.isArray(node) ? node : Object.values(node)).forEach((n) => mWalk(n, fn, depth + 1));
}
const truthy = (v) => v === true || v === 1 || v === 'true' || v === '1';

// Returnerer indeks i `choices` (de viste tekster) eller null. Gætter aldrig på ren tal-indeks.
const sNorm = (s) => String(s).toLowerCase().replace(/\[replacement_\d+\]|\?/g, '§').replace(/\s+/g, ' ').trim();


// Opgaver med en tabel i forklaringen (ich bin / du bist …): grundleddet ved siden af hullet afgør formen.
function ruleFromTable(ex, opts) {
  const html = String(ex.errorTypeDescription || '');
  const map = {};
  (html.match(/<li>[\s\S]*?<\/li>/g) || []).forEach((li) => {
    const u = li.match(/<u>([^<]+)<\/u>/);
    if (!u) return;
    const form = li.replace(/<u>[^<]*<\/u>/, '').replace(/<[^>]+>/g, '').trim().toLowerCase();
    if (!form || /\s/.test(form)) return;
    u[1].toLowerCase().split('/').forEach((p) => { (map[p.trim()] = map[p.trim()] || new Set()).add(form); });
  });
  const parts = String(ex.content.sentence).split(/\[REPLACEMENT_\d+\]/);
  if (parts.length !== 2) return null;
  const clean = (w) => (w || '').toLowerCase().replace(/[^a-zäöüßæøå]/g, '');
  const before = clean(parts[0].trim().split(/\s+/).pop());
  const after = clean(parts[1].trim().split(/\s+/)[0]);
  const subj = map[before] ? before : (map[after] ? after : null);
  if (!subj) return null;
  const hits = [];
  opts.forEach((o, i) => { if (map[subj].has(mNorm(o))) hits.push(i); });
  return hits.length === 1 ? hits[0] : null;   // tvetydigt (fx «sie») → intet gæt
}
// Grammatip-format: præcis match på den viste sætning; det rigtige svar står først i options
function findBySentence(datas, want, shown) {
  const target = sNorm(shown);
  let seen = 0, hit = null;
  datas.forEach((data) => mWalk(data, (o) => {
    if (!o || Array.isArray(o) || !o.content || typeof o.content.sentence !== 'string' || !Array.isArray(o.content.replacements)) return;
    seen++;
    if (sNorm(o.content.sentence) !== target || o.content.replacements.length !== 1) return;
    const opts = o.content.replacements[0].options;
    if (!Array.isArray(opts) || !opts.every((x) => typeof x === 'string')) return;
    if (!want.every((w) => opts.map(mNorm).includes(w))) return;
    const r = ruleFromTable(o, opts);
    hit = r == null ? null : { idx: want.indexOf(mNorm(opts[r])), why: 'regel fra opgavens tabel (grundled → form)' };
  }));
  return { seen, hit };
}

function findAnswer(datas, choices, sentence, shown) {
  const want = choices.map(mNorm);
  if (shown != null) {
    const r = findBySentence(datas, want, shown);
    if (r.hit) return r.hit;
    if (r.seen) return { idx: null, why: 'data indeholder ikke noget rigtigt-flag for denne opgave' };
  }
  const words = [...new Set(mNorm(sentence).split(/[^a-zäöüßæøå]+/).filter((w) => w.length >= 4))];
  let best = null;
  datas.forEach((data) => mWalk(data, (obj) => {
    if (Array.isArray(obj)) return;
    for (const key of Object.keys(obj)) {
      const arr = obj[key];
      if (!Array.isArray(arr) || arr.length < 2) continue;
      const texts = arr.map(mText);
      if (texts.some((t) => t == null)) continue;
      const have = texts.map(mNorm);
      if (!want.every((w) => have.includes(w))) continue;
      const js = JSON.stringify(obj).toLowerCase();
      const score = words.filter((w) => js.includes(w)).length;
      if (!best || score > best.score) best = { obj, key, arr, texts, score };
    }
  }));
  if (!best) return { idx: null, why: 'ingen opgave med de viste svarmuligheder fundet i data' };
  const { obj, key, arr, texts } = best;
  const toIdx = (i) => (i == null || i < 0 ? null : want.indexOf(mNorm(texts[i])));

  // 1) flag på selve svarmuligheden
  const flagged = [];
  arr.forEach((it, i) => { if (it && typeof it === 'object' && MINI_FLAGS.some((f) => truthy(it[f]))) flagged.push(i); });
  if (flagged.length === 1) return { idx: toIdx(flagged[0]), why: 'flag på svarmulighed' };

  // 2) felt på opgaven (correctAnswer, solution, answer …)
  for (const k of Object.keys(obj)) {
    if (k === key || !/correct|right|answer|solution|korrekt/i.test(k)) continue;
    let v = obj[k];
    if (Array.isArray(v) && v.length === 1) v = v[0];
    if (v && typeof v === 'object' && !Array.isArray(v)) { const t = mText(v); if (t != null) v = t; else if (v.id != null) v = v.id; }
    if (typeof v === 'string') {
      const j = texts.findIndex((t) => mNorm(t) === mNorm(v));
      if (j >= 0) return { idx: toIdx(j), why: 'felt ' + k + ' (tekst)' };
    }
    if (typeof v === 'string' || typeof v === 'number') {
      const j = arr.findIndex((it) => it && typeof it === 'object' && it.id != null && String(it.id) === String(v));
      if (j >= 0) return { idx: toIdx(j), why: 'felt ' + k + ' (id)' };
    }
  }
  return { idx: null, why: 'svaret ligger i en form jeg ikke genkender (fx kun et tal)' };
}

if (typeof module !== 'undefined' && module.exports) module.exports = { findAnswer };

if (typeof document !== 'undefined' && typeof chrome !== 'undefined' && chrome.storage) {
  const DEF = { enabled: true, hint: true, commaColor: '#7b8199', commaOpacity: 60, size: 'm', miniAuto: false, miniNext: false, miniDelay: 5 };
  let cfg = null, open = false, bulb = null;
  let doneKey = '', nextKey = '', pending = null, last = { why: 'ikke kørt endnu' };

  const datas = () => {
    try { return JSON.parse(document.documentElement.getAttribute('data-emh-session') || '[]').filter((x) => x.m === 'GET').map((x) => x.d); }
    catch (e) { return []; }
  };
  const q = (s) => document.querySelector(s);

  function style() {
    if (q('#emh-mini-style')) return;
    const s = document.createElement('style');
    s.id = 'emh-mini-style';
    s.textContent = `
      .emh-tick { margin-left: 8px; font-weight: 800; font-size: var(--emh-s, 1.1em); color: var(--emh-c, #2a3ea6); opacity: var(--emh-o, .6); pointer-events: none; }
      #emh-mini-bulb { position: fixed; right: 24px; bottom: 104px; z-index: 2147483000; width: 44px; height: 44px; cursor: pointer;
        border: 3px solid #1b2a6b; background: #ffe45c; border-radius: 50%; font-size: 22px; line-height: 1; padding: 0; box-shadow: 0 3px 12px rgba(0,0,0,.35); }`;
    document.head.appendChild(s);
  }

  function tick() {
    if (!cfg || !cfg.enabled) return;
    const box = q('.single-choice-exercise');
    document.querySelectorAll('.emh-tick').forEach((t) => t.remove());
    if (!box) { if (bulb) bulb.style.display = 'none'; return; }
    style();
    const btns = [...box.querySelectorAll('.choice-btn')];
    const texts = btns.map((b) => ((b.querySelector('.choice-text') || b).textContent || '').trim());
    const sentence = ((box.querySelector('.sentence-container') || {}).textContent || '').trim();
    const title = ((box.querySelector('.exercise-title') || {}).textContent || '').trim();
    const prog = (q('.progress-bar') || {}).style ? q('.progress-bar').style.width : '';
    const key = title + '|' + sentence + '|' + prog;
    last = btns.length >= 2 ? findAnswer(datas(), texts, sentence + ' ' + title, sentence) : { idx: null, why: 'ingen svarknapper' };
    const btn = last.idx != null ? btns[last.idx] : null;

    if (!bulb) {
      bulb = document.createElement('button');
      bulb.id = 'emh-mini-bulb'; bulb.type = 'button'; bulb.textContent = '💡'; bulb.setAttribute('aria-label', 'Vis svar');
      bulb.addEventListener('click', () => { open = !open; tick(); });
      document.body.appendChild(bulb);
    }
    bulb.style.display = (cfg.hint && !cfg.miniAuto) ? '' : 'none';
    const visible = !cfg.hint || (open && !cfg.miniAuto);
    if (btn && visible) {
      const t = document.createElement('span');
      t.className = 'emh-tick'; t.textContent = '✓';
      t.style.setProperty('--emh-c', cfg.commaColor);
      t.style.setProperty('--emh-o', String(Math.min(100, Math.max(20, cfg.commaOpacity)) / 100));
      t.style.setProperty('--emh-s', ({ s: 1, m: 1.2, l: 1.6 }[cfg.size] || 1.2) + 'em');
      btn.appendChild(t);
    }

    // Auto-tryk
    if (cfg.miniAuto && btn && doneKey !== key && !pending) {
      const want = texts[last.idx];
      pending = setTimeout(() => {
        pending = null;
        const cur = [...document.querySelectorAll('.single-choice-exercise .choice-btn')]
          .find((x) => ((x.querySelector('.choice-text') || x).textContent || '').trim() === want);
        if (cur && !cur.disabled) { cur.click(); doneKey = key; }
      }, 40);
    }
    // Gå videre
    if (cfg.miniNext && doneKey === key && nextKey !== key) {
      const nx = q('.auto-exercise-footer .btn-next');
      if (nx && !nx.disabled) { nextKey = key; setTimeout(() => nx.click(), Math.max(0, cfg.miniDelay) * 100); }
    }
  }

  chrome.runtime.onMessage.addListener((msg, s, send) => {
    if (msg && msg.type === 'emh-mini-dump') {
      const d = JSON.parse(document.documentElement.getAttribute('data-emh-session') || '[]');
      const box = q('.single-choice-exercise');
      send({
        fanget: d.map((x) => x.m + ' ' + x.u + (x.b ? ' body=' + x.b : '')),
        html: ((q('.auto-exercise-content') || {}).outerHTML || '').replace(/\s+/g, ' ').slice(0, 6000),
        fundet: last,
        valg: box ? [...box.querySelectorAll('.choice-text')].map((e) => e.textContent.trim()) : [],
        saetning: box ? ((box.querySelector('.sentence-container') || {}).textContent || '') : '',
        data: JSON.stringify(d).slice(0, 60000)
      });
    }
  });
  chrome.storage.local.get(DEF, (s) => { cfg = { ...DEF, ...s }; setInterval(tick, 120); });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local' || !cfg) return;
    for (const k of Object.keys(ch)) cfg[k] = ch[k].newValue;
    tick();
  });
}
