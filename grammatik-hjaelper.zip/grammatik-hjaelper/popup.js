const DEFAULTS = { enabled: true, hint: true, explain: false, miniAuto: false, miniNext: false, miniDelay: 5, commaColor: '#7b8199', commaOpacity: 60, size: 'm' };

const enabledEl = document.getElementById('enabled');
const statusEl = document.getElementById('status');
const optionsEl = document.getElementById('options');
const explainEl = document.getElementById('explain');
const colorBtn = document.getElementById('color-btn');
const colorPanel = document.getElementById('color-panel');
const colorEl = document.getElementById('comma-color');
const opacityEl = document.getElementById('opacity');
const opacityValEl = document.getElementById('opacity-val');
const dumpBtn = document.getElementById('dump-btn');
const dumpNote = document.getElementById('dump-note');
const DUMP_NOTE = dumpNote.textContent;

let state = { ...DEFAULTS };

function render() {
  enabledEl.checked = state.enabled;
  optionsEl.disabled = !state.enabled;
  statusEl.textContent = state.enabled
    ? (state.hint
      ? 'Tryk på pæren på opgavesiden for at se hjælpen.'
      : 'Hjælpen vises direkte på opgavesiden.')
    : 'Slået fra – der vises ingen hjælp.';

  const mode = document.querySelector('input[name="mode"][value="' + (state.hint ? 'hint' : 'answer') + '"]');
  if (mode) mode.checked = true;
  const size = document.querySelector('input[name="size"][value="' + state.size + '"]');
  if (size) size.checked = true;
  explainEl.checked = !!state.explain;

  colorBtn.style.background = state.commaColor;
  colorBtn.style.borderColor = state.commaColor;
  colorEl.value = state.commaColor;
  const op = Math.min(100, Math.max(20, Number(state.commaOpacity) || 60));
  opacityEl.value = op;
  opacityValEl.textContent = op + ' %';
  document.querySelectorAll('.preset').forEach((b) => {
    b.setAttribute('aria-pressed', String(b.dataset.color === state.commaColor));
  });
}

function save(patch) {
  state = { ...state, ...patch };
  chrome.storage.local.set(patch);
  render();
}

chrome.storage.local.get(DEFAULTS, (stored) => {
  state = { ...DEFAULTS, ...stored };
  render();
});

enabledEl.addEventListener('change', () => save({ enabled: enabledEl.checked }));
explainEl.addEventListener('change', () => save({ explain: explainEl.checked }));

document.querySelectorAll('input[name="mode"]').forEach((el) => {
  el.addEventListener('change', () => { if (el.checked) save({ hint: el.value === 'hint' }); });
});
document.querySelectorAll('input[name="size"]').forEach((el) => {
  el.addEventListener('change', () => { if (el.checked) save({ size: el.value }); });
});

colorBtn.addEventListener('click', () => {
  colorPanel.hidden = !colorPanel.hidden;
  colorBtn.setAttribute('aria-expanded', String(!colorPanel.hidden));
});
document.querySelectorAll('.preset').forEach((b) => {
  b.addEventListener('click', () => save({ commaColor: b.dataset.color }));
});
colorEl.addEventListener('input', () => save({ commaColor: colorEl.value }));
opacityEl.addEventListener('input', () => save({ commaOpacity: parseInt(opacityEl.value, 10) }));

function flash(text) {
  dumpNote.textContent = text;
  setTimeout(() => { dumpNote.textContent = DUMP_NOTE; }, 4000);
}
dumpBtn.addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs && tabs[0];
    if (!tab) { flash('Fandt ingen åben fane.'); return; }
    chrome.tabs.sendMessage(tab.id, { type: 'emh-dump' }, (res) => {
      if (chrome.runtime.lastError || !res) {
        flash('Åbn en opgave på grammatip.com, opdatér siden (F5), og prøv igen.');
        return;
      }
      navigator.clipboard.writeText(JSON.stringify(res, null, 1)).then(
        () => flash('Kopieret! Indsæt det i chatten med Ctrl+V.'),
        () => flash('Kunne ikke kopiere. Prøv igen.')
      );
    });
  });
});

/* ---- Mini-missioner ---- */
const miniAutoEl = document.getElementById('miniauto');
const miniNextEl = document.getElementById('mininext');
const miniDelayEl = document.getElementById('minidelay');
const miniDelayVal = document.getElementById('minidelay-val');
function renderMini() {
  miniAutoEl.checked = !!state.miniAuto;
  miniNextEl.checked = !!state.miniNext;
  miniDelayEl.value = state.miniDelay;
  miniDelayVal.textContent = (state.miniDelay / 10).toFixed(1).replace('.', ',') + ' s';
}
chrome.storage.local.get(DEFAULTS, (s) => { state = { ...DEFAULTS, ...s }; renderMini(); });
miniAutoEl.addEventListener('change', () => { save({ miniAuto: miniAutoEl.checked }); renderMini(); });
miniNextEl.addEventListener('change', () => { save({ miniNext: miniNextEl.checked }); renderMini(); });
miniDelayEl.addEventListener('input', () => { save({ miniDelay: parseInt(miniDelayEl.value, 10) }); renderMini(); });
document.getElementById('mini-dump-btn').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs && tabs[0];
    if (!tab) { flash('Fandt ingen åben fane.'); return; }
    chrome.tabs.sendMessage(tab.id, { type: 'emh-mini-dump' }, (res) => {
      if (chrome.runtime.lastError || !res) { flash('Opdatér siden (F5) og prøv igen.'); return; }
      navigator.clipboard.writeText(JSON.stringify(res, null, 1)).then(
        () => flash('Kopieret! Indsæt det i chatten med Ctrl+V.'),
        () => flash('Kunne ikke kopiere. Prøv igen.'));
    });
  });
});
